#include <stdio.h>

void echange(int *a, int *b)
 {
    int t;
    t = *a;
    *a = *b;
    *b = t;
 }
 
 int main()
  {
    int a, b, n, i = 0;
printf("donnez le nombre de fois que vous voulez faire l'echange de deux nombres \n");
scanf("%d",&n);

for ( i = 0; i < n; i++)
{   
    printf("donnez deux entier que vous voulez echanger ");
    scanf("%d %d",&a, &b);
    printf("a = %d; b = %d\n", a, b);
    echange(&a, &b);
    printf("a = %d; b = %d\n", a, b);
}

    return 0;
  }
