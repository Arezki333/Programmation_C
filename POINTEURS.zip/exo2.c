#include <stdio.h>

void divise(int p, int q, int *quotient, int *reste)
 {
    *reste = p % q;
    *quotient =p/q;
 }
 
 int main()
  {
    int a, b;
    divise(17, 3, &a, &b);
    printf("17 = %d * 3 + %d\n", a, b);
    return 0;
 }