#include <stdio.h>
#define NB_ELEM_MAXI 100

void calcul(int t[], int taille, int *somme, int *produit)
 {
    int i;
    *somme = 0;
    *produit = 1;
    for (i = 0; i < taille; i++)
     {
        *somme += t[i];
        *produit *= t[i];
     }
 }
 
 int main()
  {
    int tab[NB_ELEM_MAXI];
    int s, p, taille =-1, i;
    while (taille < 0 || taille > NB_ELEM_MAXI)
     {
        printf("Entrez le nombre d’éléments : ");
        scanf("%d", &taille);
     }
     puts("Veuillez saisir les éléments du tableau");
     for (i=0 ; i<taille ; i++)
     scanf("%d", &tab[i]);
     calcul(tab, taille, &s, &p);
     printf("somme = %d et produit = %d\n", s, p);
     return 0;
  }