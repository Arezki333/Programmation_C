#include <stdio.h>
void Modifie(int *p) /* paramètre de type pointeur */
 {
    *p = *p+1; /* ce pointeur p a pour valeur &x (x du main) */
 }
 
 int main(void)
  {
    int x=1;
    Modifie(&x); /* on passe directement l’adresse de x */
    printf("%d\n", x); /* affiche 2 */
    return 0;
  }
  