#include <stdio.h>

int main(void)
 {  int i;
    int tab[5] = {3, 56, 21, 34, 6}; /* avec point-virgule */
    size_t nb_elem = sizeof tab / sizeof *tab;
    printf ("nb_elem = %lu\n", (unsigned long) nb_elem);
    for (i=0 ; i<nb_elem ; i++) /* affichage des éléments */
    printf("tab[%d] = %d\n", i, tab[i]);
    return 0;
    }