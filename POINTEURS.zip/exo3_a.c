#include <stdio.h>

int main()
 {
    int a = 14, b = 5;
    int t;
    printf("a = %d; b = %d\n", a, b);
    t=a;
    a=b;
    b=t;
    printf("a = %d; b = %d\n", a, b);
    return 0;
 }

 