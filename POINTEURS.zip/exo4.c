#include <stdio.h>
#define NB_ELEM_MAXI 100
void raz(int *t, int taille)
 {
    int i;
    for (i = 0; i < taille; i++)
    t[i] = 0;
 }
 


int main(void)
 {  int i;
    int tab[5] = {3, 56, 21, 34, 6}; /* avec point-virgule */
    size_t nb_elem = sizeof tab / sizeof *tab;
    printf("\n");
    printf (" voici la  taille du tableau nb_elem = %lu \n", (unsigned long) nb_elem);
    printf("\n");
    for (i=0 ; i<nb_elem ; i++) /* affichage des éléments */
    printf("tab[%d] = %d\n", i, tab[i]);
    raz(tab, nb_elem);
    printf("\n");
    printf("voici mainteant l'affichage aprés l'initialisation \n");
    printf("\n");
    for (i = 0; i < nb_elem; i++)
    printf("tab[%d] = %d\n", i, tab[i]);
    
    return 0;
}

 
