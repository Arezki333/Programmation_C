#include <stdio.h>
typedef struct 
{
    int x;
}TypeStruture;

/*CAS D’UN POINTEUR SUR STRUCTURE*/

int main(void)
{ 
  TypeStruture *p; 
  TypeStruture s;
  s.x = 1;
  p = &s;
  printf("%d \n", p->x); /*L’objet p->x, équivalent à (*p).x*/
  return 0;
}




