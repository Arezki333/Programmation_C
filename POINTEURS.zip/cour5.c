#include <stdio.h>

/*PASSAGE DE PARAMÈTRE PAR VALEUR apres on va utiliser un pointeur */
void NeModifiePas(int x)
 {
    x = x+1; /* le x local est modifié, pas le x du main */
 }
 
 int main(void)
  {
    int x=1;
    NeModifiePas(x);
    printf("%d\n", x); /* affiche 1 : valeur de x inchangée */
    return 0;
 }