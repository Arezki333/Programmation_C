#include <stdio.h>

void remplir(int *a, int *b, float *x)
 {
    *a = 0;
    *b = 0;
    *x = 0.0;
 }
 
 int main()
  {
    int u, v;
    float t;
    printf("entrez 2 nombre entier puis un réel ");
    scanf("%d %d %f",&u ,&v ,&t);
    printf("voici le nombres entrer : %d  , %d  , %f  \n",u, v, t);
    remplir(&u, &v, &t);
    printf("voici les variables initialisé apres l'appel de la fonction de rénitialisation : %d , %d , %f  \n",u ,v ,t ); 
    return 0;
  }