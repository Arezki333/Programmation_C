#include <stdio.h>
/* la fonction suivante prend en paramètre un pointeur */
void Modifie(int *p)
 {
    *p = *p+1; /* p pointe sur x, la copie de p aussi *//* le x du main est modifié */
 }
 
 int main(void)
  {
    int x=1; /* la varible x n’est pas un pointeur */
    int *p;
    p = &x; /* pointeur qui pointe sur x */
    Modifie(p);
    printf("%d\n", x); /* affiche 2 */
    printf("%d\n", *p); /*ne marche pas pour le pointeur p pour que s'ammarche il faut ajouter toujour * derier p (*p)  */
    return 0; /* l'affichage d'un poiteur est  printf("%d\n", *p) */
  }