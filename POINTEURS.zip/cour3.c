#include <stdio.h>
int main(void)
 {
    int x=2;
    int *p = &x; /* x et *p deviennent synonymes */
    printf("La valeur de x est %d\n", *p); /* affiche 2 */
    x=5;
    printf("La nouvelle valeur de x est %d\n", *p);/* doit afficher la valeur 5 */
    return 0;
 }