#include <stdio.h>
int main(void)
 {
    int x=2;
    int *p = &x; /* x et *p deviennent synonymes */
    *p = 3;
    printf("La nouvelle valeur de x est %d\n", x); /* doit afficher la valeur 3 */
    return 0;
 }