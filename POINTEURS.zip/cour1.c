#include <stdio.h>
int main(void)
 {
    int x=2;/* déclaration d’une variable x */
    int *p; /* déclaration d’un pointeur p */
    p = &x; /* p pointe sur x *//* la valeur de p est l’adresse de x */
    printf("la valeur de x est 2 fixé avant mainteant en va pointer la valeur de x par \n un pointeur et en va associée une valeur au pointeur \n donner la vouvelle valeur de x par le pointeur " );
    scanf("%d", p); /* lecture de la valeur de x au clavier */
    printf(" voici la nouvelle valeur de x par le pointeur p ==>%d\n", x); /* affichage de la nouvelle valeur de x */
    return 0;
 }