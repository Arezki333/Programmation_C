#include <stdio.h>

typedef struct point
 {
    float x, y;
 } Point;

 void echange(Point * a, Point * b)
  {
    Point t;
    t.x = a->x;
    t.y = a->y;
    a->x = b->x;
    a->y = b->y;
    b->x = t.x;
    b->y = t.y;
  }

  int main()
   {
    Point M, N;
    printf("Coordonnées du premier point ? \n");
    scanf("%f %f", &M.x, &M.y);
    printf("Coordonnées du second point ? \n");
    scanf("%f %f", &N.x, &N.y);
    printf("M(%f,%f) et N(%f,%f)\n", M.x, M.y, N.x, N.y);
    echange(&M, &N);
    printf("M(%f,%f) et N(%f,%f)\n", M.x, M.y, N.x, N.y);
    return 0;
   }