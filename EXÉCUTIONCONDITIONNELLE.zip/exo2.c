#include <stdio.h>
int main(void)
 {
    float prix, tva, ttc;
    char type;
    printf("Entrez un prix : \n");
    scanf("%f", &prix);
    printf("Produit de type A ou B?\n");
    getchar();
    type = (char) getchar();
    if (type == 'A')
     {
        tva = 5.5;
     }else
      {
        tva = 19.6;
      }
      ttc = prix * (1.0 + tva / 100.0);
      printf("Prix TTC : %f (TVA à %.1f %%)\n", ttc, tva);
      return 0;
 }