#include <stdio.h>
int main(void)
 {
    int n1, n2, temp;
    printf("Entrez deux nombres entiers : ");
    scanf("%d %d", &n1, &n2);
    if (n1 > n2)
     {
        temp = n1;
        n1 = n2;
        n2 = temp;
     }
     printf("Plus petit : %d ; plus grand : %d\n", n1, n2);
return 0;
}

