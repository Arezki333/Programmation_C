#include <stdio.h>
int main(void){
 char choix;
 puts("Attention, ce programme est susceptible de");
 puts("heurter la sensibilité de ceux d’entre vous");
 puts("qui sont allergiques aux maths !");
 puts("\nVoulez-vous continuer ? (y/n)");
 choix = getchar(); /* getchar permet de saisir un caractère */
  if (choix == 'y')
   {
    puts("Le carré de l’hypoténuse est égal à");
    puts("la somme des carrés des deux autres côtés !");
   }
  if (choix == 'n')
  puts("Bon, bon, tant pis pour vous...");

    return 0;
}
