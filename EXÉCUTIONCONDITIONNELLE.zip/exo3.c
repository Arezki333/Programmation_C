#include <stdio.h>
int main(void)
 {
    float a, b, c, max;
    printf("Entrez trois nombres réels : ");
    scanf("%f %f %f", &a, &b, &c);
    if (a < b)
    max = b;
    else max = a;
    if (max < c)
    max = c;
    printf("Le maximum des trois nombres est %f\n", max);
    return 0;
 }