#include <stdio.h>
int main(void)
 {
    char c1, c2, c;
    printf("Entrez deux caractères parmi + et - : ");
    scanf("%c %c", &c1, &c2);
    if (((c1 != '-') && (c1 != '+')) && ((c2 != '-') && (c2 != '-')))
    printf("Entrée incorrecte...\n");
    else
     {
        if (c1 == c2)
        c = '+';
        else
        c = '-';
        printf("Le signe du produit est %c\n", c);
     }
     return 0;
 }