#include <stdio.h>
/*Opérations booléennes*/
/*Négation*/
int main(void)
{
    char papiers, rad;
    puts("Avez-vous vos papiers ? (y/n)");
    papiers = getchar();
    getchar();
    puts("Avez-vous quelque chose à déclarer ? (y/n)");
    rad = getchar();
    if (!(papiers == 'y' && rad == 'n'))
    puts("Attendez là s’il vous plaît.");
    return 0;
}
