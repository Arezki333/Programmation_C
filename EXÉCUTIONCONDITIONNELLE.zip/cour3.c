#include <stdio.h>
int main(void)
{
  int reponse;
  puts("Tapez 1 pour conserver le message, 0 pour l’effacer");
  scanf("%d", &reponse);
  if (reponse) /* Si réponse est différent de zéro ! */
  printf("le message est conserver  \n");
  else
  printf("le messsage est effacer \n");
 
    return 0;
}