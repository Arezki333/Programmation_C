#include <stdio.h>
/*switch*/

int main(void)
{
    char choix;
    puts("Menu : faites un choix:\n");
    puts("Afficher la liste des clients -----> a");
    puts("Afficher les données d’un client --> b");
    puts("Saisir un client ------------------> c");
    puts("Quitter ---------------------------> d");
    choix = getchar();
    switch(choix)
     {
        case 'a' : puts("Affichage de la liste des clients");/* mettre ici le code d’affichage des clients */
        break;
        case 'b' : puts("Affichage des données d’un client");
                   puts("Veuillez entrer le nom du client");/* mettre ici le code de saisie et d’affichage */
        break;
        case 'c' : puts("Saisie des données du client");
        puts("Veuillez entrer les données");/* mettre ici le code de saisie des données */
        break;
        case 'd' :break;
        default : puts("Erreur de saisie du choix !");
     }
    return 0;
}
