#include <stdio.h>
/*Opérations booléennes*/
/*Conjonction*/
int main(void)
{
 char papiers, rad;
 puts("Avez-vous vos papiers ? (y/n)");
 papiers = getchar();
 getchar(); /* getchar pour manger le retour chariot */
 puts("Avez-vous quelque chose à déclarer ? (y/n)");
 rad = getchar();
 if (papiers == 'y' && rad == 'n')
 puts("O.K., vous pouvez passer. Bon voyage.");

    return 0;
}