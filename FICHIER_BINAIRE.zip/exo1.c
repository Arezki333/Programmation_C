#include <stdio.h>
#include <stdlib.h>


void Affichage(char *nomFichier)
 {
    int n, ret, i;
    double *tableau;
    FILE *fp;
    if ((fp = fopen(nomFichier, "rb")) == NULL)
     {
        puts("Erreur : fichier inexistant ou droits insuffisants");
        exit(1);
     }
     fread(&n, sizeof(int), 1, fp);
     printf("n=%d\n", n);
     tableau = (double *) malloc(n * sizeof(double));
     ret = fread(tableau, sizeof(double), n, fp);
     if (ret != n)
      {
        puts("erreur de lecture ou fin de fichier");
        exit(1);
      }
      fclose(fp);

      printf("Les éléments du tableau : \n");
      for (i = 0; i < n; i++)
      printf("%lg\n", tableau[i]);
      free(tableau);
}

void Saisie(char *nomFichier)
 {
    int n, i;
    double valeur;
    FILE *fp;
    if ((fp = fopen(nomFichier, "wb")) == NULL)
     {
        puts("Permission non accordée ou répertoire inexistant");
        exit(1);
     }
     
     printf("Entrez le nb d’éléments\n");
     scanf("%d", &n);
     fwrite(&n, sizeof(int), 1, fp);
     for (i = 0; i < n; i++)
      {
        printf("Entrer élément %d du tableau\n", i + 1);
        scanf("%lg", &valeur);
        fwrite(&valeur, sizeof(double), 1, fp);
      }
      fclose(fp);
 }


 void Afficheab(char *nomFichier, double a, double b)
  {
    double valeur;
    int n, ret, i;
    FILE *fp;
    if ((fp = fopen(nomFichier, "rb")) == NULL)
     {
        puts("Erreur : fichier inexistant ou droits insuffisants");
        exit(1);
     }
     ret = fread(&n, sizeof(int), 1, fp);
     if (ret < 1)
     {
        printf("Erreur de lecture ou fin du fichier\n");
        exit(1);
     }
     printf("Les éléments compris entre %lg et %lg :\n",a,b);
     for (i = 0; i < n; i++)
      {
        ret = fread(&valeur, sizeof(double), 1, fp);
        if (valeur >= a && valeur <= b)
        printf("%lg\t", valeur);
      }
      puts("");
      fclose(fp);
    }

    void Affichageieme(char *nomFichier, int i)
     {
        double valeur;
        int n, ret;
        FILE *fp;
        if ((fp = fopen(nomFichier, "rb")) == NULL)
         {
            puts("Erreur : fichier inexistant ou droits insuffisants");
            exit(1);
         }
         fseek(fp, (1) * sizeof(int) + (i - 1) * sizeof(double), SEEK_SET);
         ret = fread(&valeur, sizeof(double), 1, fp);
         if (ret < 1)
          {
            printf("Erreur de lecture ou fin du fichier\n");
            fclose(fp);
            exit(1);
          }
          else
          printf("ième élément= %lg\n", valeur);
          fclose(fp);
     }


     void AffichageAvantDernier(char *nomFichier)
      {
        double valeur;
        int n, ret;
        FILE *fp;
        if ((fp = fopen(nomFichier, "rb")) == NULL)
         {
            puts("Erreur : fichier inexistant ou droits insuffisants");
            exit(1);
         }
         fseek(fp, -2 * sizeof(double), SEEK_END);
         ret = fread(&valeur, sizeof(double), 1, fp);
         if (ret < 1)
          {
            printf("Erreur de lecture ou fin du fichier\n");
          }
          else
          printf("Avant dernier élément= %lg\n", valeur);
       }


       
