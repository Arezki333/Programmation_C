#include <stdio.h>
#include <stdlib.h>
typedef struct
 {
    int code;
    char denomination[100];
    float prix;
    int stock;
 } TypeArticle;

 TypeArticle *Chargement(char *nom_fichier, int *nb)
  {
    FILE *fp;
    int i;
    TypeArticle *tab;
    fp = fopen(nom_fichier, "rb");
    if (fp == NULL)
     {
        fprintf(stderr, "Problème fopen");
        exit(1);
     }
     fread(nb, sizeof(int), 1, fp);
     printf("nb Chargement=%d\n", *nb);
     tab = (TypeArticle *) malloc((*nb) * sizeof(TypeArticle));
     for (i = 0; i < *nb; i++)
     {
        fread(&tab[i].code, sizeof(int), 1, fp);
        fread(tab[i].denomination, 100, 1, fp);
        fread(&tab[i].prix, sizeof(float), 1, fp);
        fread(&tab[i].stock, sizeof(int), 1, fp);
     }
      fclose(fp);
      for (i = 0; i < *nb; i++)
       {
        printf("%d\t%s\t%f\t%d\n", tab[i].code, tab[i].denomination,tab[i].prix, tab[i].stock);
       }
       return tab;
  }

  void Sauvegarde(char *nomfichier)
   {
    TypeArticle *tab;
    int i, nb;
    FILE *fp;
    if ((fp = fopen(nomfichier, "wb")) == NULL)
     {
        puts("permission non accordée ou répertoire inexistant");
        exit(1);
     }
     printf("Entrer le nombre d’articles\n");
     scanf("%d", &nb);
     tab = (TypeArticle *) malloc((nb) * sizeof(TypeArticle));
     fwrite(&nb, sizeof(int), 1, fp);
     for (i = 0; i < nb; i++)
      {
        printf("Entrer le code de l’article à rajouter\n");
        scanf("%d", &tab[i].code);
        printf("Entrer la nouvelle nomination\n");
        scanf("%s", &tab[i].denomination);
        fscanf(stdin, "%*c");
        tab[i].denomination[strlen(tab[i].denomination)] = '\0';
        printf("Entrer le nouveau prix \n");
        scanf("%f", &tab[i].prix);
        printf("Entrer le nouveau stock\n");
        scanf("%d", &tab[i].stock);
        fwrite(&tab[i].code, sizeof(int), 1, fp);
        fwrite(tab[i].denomination, 100, 1, fp);
        fwrite(&tab[i].prix, sizeof(float), 1, fp);
        fwrite(&tab[i].stock, sizeof(int), 1, fp);
       } free(tab);
       fclose(fp);
    }

    int Recherche(TypeArticle * tableau, char *denomination, int nb)
     {
        int i, cmp;
        for (i = 0; i < nb; i++)
         {
            cmp = strcmp(denomination, tableau[i].denomination);
            if (cmp == 0)
            return tableau[i].code;
         }
         return -1;
     }

     void Affichearticlecode(TypeArticle * tableau, int code, int nb)
      {
        int i, a;
        for (i = 0; i < nb; i++)
         {
            if (tableau[i].code == code)
             {
                printf("code %d : denomination=%s, prix=%f, stock=%d \n",tableau[i].code, tableau[i].denomination,tableau[i].prix, tableau[i].stock);
                break;
             }
         }
         printf("Le code recherché n’existe pas");
      }  


     int Modifiearticlecode(char *nomfichier, int code)
      {
        int i, nb;
        TypeArticle Article;
        FILE *fp;
        if ((fp = fopen(nomfichier, "r+b")) == NULL)
         {
            puts("permission non accordée ou répertoire inexistant");
         }
         fread(&nb, sizeof(int), 1, fp);
         printf("nb=%d\n", nb);
         for (i = 0; i < nb; i++)
          {
            fread(&Article.code, sizeof(int), 1, fp);
            printf("code=%d\n", code);
            if (Article.code == code)
             {
                printf("Entrer la nouvelle nomination\n");
                scanf("%s", Article.denomination);
                fscanf(stdin, "%*c");
                Article.denomination[strlen(Article.denomination)] = '\0';
                printf("Entrer le nouveau prix\n");
                scanf("%f", &Article.prix);
                printf("Entrer le nouveau stock\n");
                scanf("%d", &Article.stock);
                fwrite(Article.denomination, 100, 1, fp);
                fwrite(&Article.prix, sizeof(float), 1, fp);
                fwrite(&Article.stock, sizeof(int), 1, fp);
                fclose(fp);
                return (0);
              }
              fseek(fp, (100 + sizeof(float) + sizeof(int)), SEEK_CUR);
            }
             printf("article non trouvé\n");
             fclose(fp);
             return 1;
        }

        void Saisienouveauarticle(char *nomfichier)
         {
            int i, a, nb;
            TypeArticle Article;
            FILE *fp;
            fp = fopen(nomfichier, "r+b");
            if (fp == NULL)
             {
                fprintf(stderr, "Problème fopen");
                exit(1);
             }
             fread(&nb, sizeof(int), 1, fp);
             printf("Saisienouveau article=%d\n", nb);
             printf("Entrer le code de l’article à rajouter\n");
             scanf("%d", &Article.code);
             printf("Entrer la nouvelle nomination\n");
             scanf("%s", Article.denomination);
             fscanf(stdin, "%*c");
             Article.denomination[strlen(Article.denomination) - 1] = '\0';
             printf("Entrer le nouveau prix\n");
             scanf("%f", &Article.prix);
             printf("Entrer le nouveau stock\n");
             scanf("%d", &Article.stock);
             nb=nb+1;
             fseek(fp, 0, SEEK_SET);
             fwrite(&nb, sizeof(int), 1, fp);
             fseek(fp, 0, SEEK_END);
             fwrite(&Article.code, sizeof(int), 1, fp);
             fwrite(Article.denomination, 100, 1, fp);
             fwrite(&Article.prix, sizeof(ﬂoat), 1, fp);
             fwrite(&Article.stock, sizeof(int), 1, fp);
             fclose(fp);
        }

        int Suprimearticle(char *nomfichier, int code)
         {
            int i = 0, nb, flag = 0;
            TypeArticle Article;
            FILE *fp;
            if ((fp = fopen(nomfichier, "r+b")) == NULL)
             {
                puts("permission non accordée ou répertoire inexistant");
             }
             fread(&nb, sizeof(int), 1, fp);
             while (i < nb && flag == 0)
              {
                fread(&Article.code, sizeof(int), 1, fp);
                if (Article.code == code)
                 {
                    flag = 1;
                 }
                 i++;
                 fseek(fp, 100 + sizeof(float) + sizeof(int), SEEK_CUR);
              }
              if (flag == 0)
               {
                printf("article non trouvé\n");
                fclose(fp);
                return 1;
                }
                if (flag == 1 && i == nb) /* l’article à supprimer est le dernier */
                 {
                    fseek(fp, 0, SEEK_SET);
                    nb=nb-1;
                    fwrite(&nb, sizeof(int), 1, fp);
                    fclose(fp);
                    return 1;
                 }
                 while (i < nb)
                  {
                    fread(&Article.code, sizeof(int), 1, fp);
                    fread(Article.denomination, 100, 1, fp);
                    fread(&Article.prix, sizeof(float), 1, fp);
                    fread(&Article.stock, sizeof(int), 1, fp);
                    fseek(fp, -2 * (sizeof(int) + 100 + sizeof(float) + sizeof(int)),SEEK_CUR);
                    fwrite(&Article.code, sizeof(int), 1, fp);
                    fwrite(Article.denomination, 100, 1, fp);
                    fwrite(&Article.prix, sizeof(float), 1, fp);
                    fwrite(&Article.stock, sizeof(int), 1, fp);
                    i++;
                    fseek(fp, 1 * (sizeof(int) + 100 + sizeof(float) + sizeof(int)),SEEK_CUR);
                  }
                   fseek(fp, 0, SEEK_SET);
                   nb=nb-1;
                   fwrite(&nb, sizeof(int), 1, fp);
                   fclose(fp);
                   return 0;
                }

