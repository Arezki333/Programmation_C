#include <stdio.h>
#include <stdlib.h>

#define fichier "fichier_lecture_poids.txt"
#define NB_ELEM_MAXI 200

int main()
 {
    FILE *fp;
    int t, n, somme;
    fp = fopen(fichier, "rt");
    if (fp == NULL)
     {
        printf("Erreur de lecture fichier\n");
        return -1;
     }
     n=0;
     somme = 0;
     while (fscanf(fp, "%d", &t) == 1)
      {
        somme += t;
        n++;
      }
      
      fclose(fp);
      printf("Moyenne = %f\n", somme / (float) n);
      return 0;
}