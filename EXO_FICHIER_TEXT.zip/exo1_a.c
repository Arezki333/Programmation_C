#include <stdio.h>
#include <stdlib.h>

#define fichier "fichier_lecture_poids.txt"
#define NB_ELEM_MAXI 200


int main()
 {
    FILE *fp;
    int t[NB_ELEM_MAXI], i, somme;
    fp = fopen(fichier, "rt");
    if (fp == NULL)
     {
        printf("Erreur de lecture fichier\n");
        return -1;
     }
     i=0;
     while (fscanf(fp, "%d", &t[i]) == 1)
     i++;
     fclose(fp);
     somme = 0;
     i--;
     while (i >= 0)
      {
        somme += t[i];
        i--;
      }
      printf("Moyenne = %f\n", somme / (float) NB_ELEM_MAXI);
      return 0;
}    