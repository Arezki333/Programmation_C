#include <stdio.h>
#include <stdlib.h>

#define NB_LIGNES_MAX 100
#define NB_COLONNES_MAX 50

void Saisie(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX], int *nbl, int *nbc)
 {
    int i, j;
    puts("Entrez le nombre de lignes et de colonnes");
    scanf("%d %d", nbl, nbc);
    for (i = 0; i < *nbl; i++)
     {
        printf("Entrez la ligne %d\n", i + 1);
        for (j = 0; j < *nbc; j++)
        scanf("%d", &tableau[i][j]);
     }
}

void CompteApparitionx(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX], int nbl,int nbc, int x)
 {
    int i, j, compteurx = 0;
    for (i = 0; i < nbl; i++)
    for (j = 0; j < nbc; j++)
    if (tableau[i][j] == x)
    compteurx++;
    printf("Le nombre %d apparaît %d fois\n", x, compteurx);
}


int *tableauparite(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX],int nbl, int nbc, int *nbtableau)
 {
    int i, j;
    int *tabparite;
    *nbtableau = 0;
    tabparite = (int *) malloc(nbl * nbc * sizeof(int));
    for (i = 0; i < nbl; i++)
    for (j = 0; j < nbc; j++)
    if (tableau[i][j] % 2 == 0)
     {
        tabparite[*nbtableau] = tableau[i][j];
        (*nbtableau)++;
     }
     return tabparite;
}

int Compteparite(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX], int nbl, int nbc)
 {
    int i, j, nbtableau = 0;
    for (i = 0; i < nbl; i++)
    for (j = 0; j < nbc; j++)
    if (tableau[i][j] % 2 == 0)
    nbtableau++;
    return nbtableau;
 }

 int main(void)
  {
    int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX];
    int nbl, nbc, nbtableau;
    if (nbl > NB_LIGNES_MAX || nbc > NB_COLONNES_MAX)
    {
        puts("Erreur, nombre dépassant la taille du tableau");
        exit(1);
    }
    Saisie(tableau, &nbl, &nbc);
    nbtableau = Compteparite(tableau, nbl, nbc);
    printf("le nombre d’éléments qui sont pairs dans le tableau= %d \n",nbtableau);
    return 0;
  }