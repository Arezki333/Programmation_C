#include<stdio.h>
#include <stdlib.h>

#define NB_LIGNES_MAX 100
#define NB_COLONNES_MAX 50
void Creer(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX],int nbl, int nbc)
 {
    int i, j;
    for (i=0 ; i<nbl ; i++) /* pour chaque ligne du tableau */
    for (j=0 ; j<nbc ; j++) /* pour chaque colonne */
    tableau[i][j] = i+j;
 }
 
 void Afficher(int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX],int nbl, int nbc)
  {
    int i, j;
    for (i=0 ; i<nbl ; i++) /* pour chaque ligne */
     {
        for (j=0 ; j<nbc ; j++) /* pour chaque colonne */
        printf("%d ", tableau[i][j]);
        printf("\n"); /* on va à la ligne */
     }
  }

  int main(void)
   {
    int tableau[NB_LIGNES_MAX][NB_COLONNES_MAX];
    int nbl, nbc;
    puts("Entrez le nombre de lignes et de colonnes");
    scanf("%d %d", &nbl, &nbc);
    if (nbl > NB_LIGNES_MAX || nbc > NB_COLONNES_MAX)
    {
        puts("Erreur, nombre dépassant la taille du tableau");
        exit(1);
    }
    Creer(tableau, nbl, nbc);
    Afficher(tableau, nbl, nbc);
    return 0;
  }