#include <stdio.h>
typedef struct bois
 {
    float largeur, longueur, epaisseur;
    char essence;
 } Panneaux;

 Panneaux Saisie()
  {
    Panneaux p;
    printf("Entrez la largeur, la longueur , l’épaisseur , le type du bois: \n");
    scanf("%f %f %f", &p.largeur, &p.longueur, &p.epaisseur);
    printf("Entrez l’essence de bois : ");
    scanf("%c", &p.essence);/* ne marche pas */
    return p;
  }

  void Affichage(Panneaux p)
   {
    printf("Panneau en ");
    switch (p.essence)
     {
        case '0':printf("pin\n");
                 break;
        case '1':printf("chêne\n");
                 break;
        case '2':printf("hêtre\n");
                 break;
        default:printf("inconnue\n");
      }
      
      printf("largeur = %f ; longueur = %f ; epaisseur = %f\n",p.largeur, p.longueur, p.epaisseur);
 }

 float Volume(Panneaux p)
 {
    return (p.largeur * p.longueur * p.epaisseur) / 1e9;
 }

int main(void)
{   float vol;
    Panneaux p1;
            printf("saisie de la largeur, une longueur et une épaisseur et aussi le type du bois\n");
            p1=Saisie();
            vol=Volume(p1);   
            printf("voivi l'affichage \n");
            Affichage(p1);
            printf("\n");
            printf("voici le volume du bois :%f \n", vol);
        
        

    return 0;
}

