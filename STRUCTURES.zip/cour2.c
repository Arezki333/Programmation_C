#include <stdio.h>
typedef struct point
 {
     /* déclaration de la structure */
     float x,y,z;
 }Point3D;

  /* la fonction suivante prend un Point3D en paramètre */
  
  void Affiche(Point3D P)
   {
    /* Affichage des champs : */
    printf("(%f, %f, %f)", P.x, P.y, P.z);
   }
   /* la fonction suivante retourne la structure */
   Point3D SaisiePoint3D(void)
    {
        Point3D P; /* variable de type Point3D */
        printf("Entrez trois coordonnées séparées par des espaces\n");
        scanf("%f %f %f", &P.x, &P.y, &P.z);
         /* saisie des champs */
         return P; /* on retourne la variable */
     }
     
     Point3D Addition(Point3D P1, Point3D P2)
      {
        Point3D resultat;
        resultat.x = P1.x + P2.x; /* calcul des coordonnées */
        resultat.y = P1.y + P2.y; /* accès aux champs par un . */
        resultat.z = P1.y + P2.z;
        return resultat; /* la fonction retourne la structure */
       }
       
       int main(void)
        {
            Point3D p1, p2, add;
            printf("Entrez les coordonnées de deux points\n");
            p1 = SaisiePoint3D(); /* on récupère la structure saisie */
            p2 = SaisiePoint3D();
            add = Addition(p1,p2); /* appel de la fonction addition */
            printf("L’addition vaut : \n");
            Affiche(add);
            printf("\n");
            return 0;
        }