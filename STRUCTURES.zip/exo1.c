#include <stdio.h>

typedef struct rationnel
 {
    float numerateur, denominateur;
 } NombreRationnel;
 
 
 NombreRationnel Saisie()
 {
    NombreRationnel n;
    printf("Entrez le numérateur et le dénominateur : ");
    scanf("%f %f", &n.numerateur, &n.denominateur);
    return n;
 }
 
 void Affichage(NombreRationnel n)
  {
    printf("%.2f/%.2f\n", n.numerateur, n.denominateur);
  }
  
  NombreRationnel Multiplier(NombreRationnel p, NombreRationnel q)
   {
    NombreRationnel r;
    r.numerateur = p.numerateur * q.numerateur;
    r.denominateur = p.denominateur * q.denominateur;
    return r;
   }
   
   NombreRationnel Additionner(NombreRationnel p, NombreRationnel q)
    {
        NombreRationnel r;
        r.numerateur =p.numerateur * q.denominateur + q.numerateur * p.denominateur;
        r.denominateur = p.denominateur * q.denominateur;
        return r;
    }

    int main(void)
    {
       NombreRationnel p, q, add, mul;
            printf("saisie de deux nombre rationnel\n");
            printf("saisie du premier nombre p :\n");
            p = Saisie(); /* on récupère la structure saisie */
            printf("saisie du 2éme nombre q :\n ");
            q = Saisie();
            add = Additionner(p,q); /* appel de la fonction addition */
            mul = Multiplier(p,q);
            printf("L’addition vaut : \n");
            Affichage(add);
            printf("La multiplication vaut : \n");
            Affichage(mul);
            printf("\n");
        
        

       return 0;
    }
    