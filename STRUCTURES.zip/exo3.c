#include <stdio.h>

typedef struct produit
 {
    char type;
    unsigned int reference;
    float prix;
    unsigned int quantite;
 } Produit;

 Produit Saisie()
  {
    Produit p;
    printf("Entrez le code du produit : \n");
    scanf("%c", &p.type);
    printf("Entrez la référence : \n");
    scanf("%u", &p.reference);
    printf("Entrez le prix : \n");
    scanf("%f", &p.prix);
    printf("Entrez la quantité : \n");
    scanf("%u", &p.quantite);
    return p;
  }

  void Affichage(Produit p)
   {
    printf("Type : %c\n", p.type);
    printf("Référence : %u\n", p.reference);
    printf("Prix : %f\n", p.prix);
    printf("Quantité : %u\n", p.quantite);
   }

   void Commande()
    {
        unsigned int qte;
        Produit p = Saisie();
        printf("Entrez la quantité commandée : ");
        scanf("%u", &qte);
        printf("\nRécapitulatif de la commande\n");
        Affichage(p);
        printf("Valeur de la commande : %.2f\n", p.prix * qte);
    }

int main(void)
{  
 Produit p1 ; 
  p1 = Saisie();
  Affichage(p1);
  printf("\n");
  Commande();      
    return 0;
}
