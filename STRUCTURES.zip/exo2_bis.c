#include <stdio.h>
typedef struct bois
 {
    float largeur, longueur, epaisseur;
    char essence;
 } Panneaux;

 Panneaux Saisie()
  {
    Panneaux p;
    printf("Entrez la largeur, la longueur , l’épaisseur , le type du bois: \n");
    scanf("%f %f %f %c", &p.largeur, &p.longueur, &p.epaisseur, &p.essence);
    return p;
  }

  void Affichage(Panneaux p)
   {
    printf("Panneau en ");
    switch (p.essence)
     {
        case '0':printf("pin\n");
                 break;
        case '1':printf("chêne\n");
                 break;
        case '2':printf("hêtre\n");
                 break;
        default:printf("inconnue\n");
      }
      
      printf("largeur = %f ; longueur = %f ; epaisseur = %f\n ; volume = %lf \n",p.largeur, p.longueur, p.epaisseur, (p.largeur * p.longueur * p.epaisseur) / 1e9);
 }

 float Volume(Panneaux p)
 {
    return (p.largeur * p.longueur * p.epaisseur) / 1e9;
 }

int main(void)
{   
    Panneaux p1;
            p1=Saisie();
            printf("voici l'affichage \n");
            Affichage(p1);
            printf("\n");
            
        
        

    return 0;
}

