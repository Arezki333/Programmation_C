#include <stdio.h>
#include <stdlib.h> /* pour utiliser malloc *//* fonction retournant un pointeur de type float* */
float* RentrerTableau(int *addrNbreElements)
 {
    int n, i;
    float *tab; /* adresse du tableau (type pointeur) */
    printf("Entrez la taille du tableau : ");
    scanf("%d", &n);
    *addrNbreElements = n; /* passage par adresse, renvoi de n *//* le nombre d’éléments connu, on alloue le tableau */
    tab = (float*)malloc(n*sizeof(float)); /* allocation */
    puts("Entrez les éléments du tableau :");
    for (i=0 ; i<n ; i++)
    scanf("%f", &tab[i]);
    return tab; /* on retourne l’adresse du tableau */
 }
 
 void Affichage(float *tab, int nb) /* affiche un tableau tab */
  {
    int i;
    for (i=0 ; i<nb ; i++)
    printf("tab[%d] = %f\n", i, tab[i]);
  }
  
  int main(void)
   {
    int nb;
    float *tab;
    tab = RentrerTableau(&nb);/* on récupère l’adresse du tableau dans tab */
    Affichage(tab, nb);
    free(tab); /* libération de mémoire obligatoire */
    return 0;
   }

