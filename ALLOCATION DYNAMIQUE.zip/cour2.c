#include <stdio.h>
#include <stdlib.h> /* pour utiliser calloc */

float* RentrerTableauBis(int *addrNbreElements)
 {
    int i, n;char choix;
    float *tab; /* adresse du tableau */
    printf("Entrez la taille du tableau : ");
    scanf("%d", &n);
    *addrNbreElements = n; /* passage par adresse *//* le nombre d’éléments connu, on alloue le tableau */
    tab = (float*)calloc(n, sizeof(float)); /* allocation */
    puts("Entrez les éléments non nuls du tableau :");
    choix = 'y';
    while (choix=='y')
   {
        puts("Entrez l’indice i de l’élément à saisir");
        scanf("%d", &i);
        puts("Entrez l’élément tab[i]");
        scanf("%f", &tab[i]);
        getchar(); /* pour manger le retour chariot */
        puts("Y-a-t’il un autre élément non nul ? (y/n)");
       choix = getchar();
   }
 
   return tab; /* on retourne l’adresse du tableau */
}



void Affichage(float *tab, int nb)
 {
    int i;
    for (i=0 ; i<nb ; i++)
    printf("tab[%d] = %f\n", i, tab[i]);
 }
 
 int main(void)
  {
    int nb;
    float *tab;
    tab = RentrerTableauBis(&nb);
    Affichage(tab, nb);
    free(tab); /* libération de mémoire obligatoire */
    return 0;
  }

