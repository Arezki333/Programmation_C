#include <stdio.h>
#include <stdlib.h>


typedef struct
 {
    int nb_elem;
    int *tab;
 }
  TypeTableau;

#define N 5


TypeTableau CreationTableau(int n)
 {
    TypeTableau t;
    t.nb_elem = 0;
    t.tab = NULL;
    if (n > 0)
     {
        t.tab = calloc(n, sizeof(int));
        if (t.tab != NULL)
        t.nb_elem = n;
     }
     return t;
 }

 void DestructionTableau(TypeTableau T)
  {
    if (T.nb_elem > 0)
     {
        free(T.tab);
        T.nb_elem=0;
     }
  }

  void SimpleLectureTableau(TypeTableau T)
   {
    int i;
    for (i = 0; i < T.nb_elem; i++)
     {
        printf("T[%d] = ? ", i);
        scanf("%d", &(T.tab[i]));
     }
   }

   void Affichage(TypeTableau T)
    {
        int i;
        for (i = 0; i < T.nb_elem;i++)
         {
            printf("T[%d] = %d\n", i, T.tab[i]);
         }
         
    }

    TypeTableau DoubleTableau(TypeTableau T)
     {
        TypeTableau TT = CreationTableau(T.nb_elem);
         int i;
         for (i = 0; i < T.nb_elem; i++)
          {
            TT.tab[i] = 2 * T.tab[i];
          }return TT;
     }

int main()
 {
    TypeTableau Ta, TaTa;
    Ta = CreationTableau(N);
    SimpleLectureTableau(Ta);
    TaTa = DoubleTableau(Ta);
    Affichage(TaTa);
    DestructionTableau(Ta);
    DestructionTableau(TaTa);
    return 0;
 }