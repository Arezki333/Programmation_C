#include <stdio.h>
#include <stdlib.h>

unsigned int *suite(unsigned int n)
 {
    unsigned int *un = NULL;
    unsigned int i;
    if (n <= 0)
    return un;
    un = calloc(n, sizeof(unsigned int));
    if (un != NULL)
     {
        un[0] = 1;
        i=1;
        while (i < n)
         {
            un[i] = 3 * un[i - 1] * un[i - 1] + 2 * un[i -1] + 1;
            i++;
         }
     }
     return un;
 }

 int main()
  {
    unsigned int n;
    unsigned int *u;
    unsigned int i;
    printf("Nombre de termes ? ");
    scanf("%u", &n);
    u = suite(n);
    if (u == NULL)
    return -1;
    i=0;
    while (i < n)
     {
        printf("u_%u = %u\n", i, u[i]);
        i++;
     }
     return 0;
  }