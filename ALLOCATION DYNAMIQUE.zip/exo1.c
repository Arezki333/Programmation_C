#include <stdio.h>
#include <stdlib.h>

int *zero(int *n)
 {
    int *t = NULL;
    printf("Entrez une taille : ");
    scanf("%d", n);
    if (*n > 0)
     {
        t = calloc(*n, sizeof(int));
     }
     
     return t;
 }


 void Affichage(int *tab, int nb)
 {
    int i;
    for (i=0 ; i<nb ; i++)
    printf("tab[%d] = %d\n", i, tab[i]);
 }
 
 int main(void)
  {
    int nb;
    int *tab;
    tab = zero(&nb);
    Affichage(tab, nb);
    free(tab); /* libération de mémoire obligatoire */
    return 0;
  }

