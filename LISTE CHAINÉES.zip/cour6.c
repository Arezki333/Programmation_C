


void Liberation(TypeCellule **pL)/* passage d’un pointeur par adresse : */
/* pointeur sur pointeur */
 {
    TypeCellule *p;
    while (*pL != NULL) /* tant que la liste est non vide */
     {
        p = *pL; /* mémorisation de l’adresse de la cellule */
        *pL = (*pL)->suivant; /* cellule suivante */
        free(p); /* destruction de la cellule mémorisée */
     }
     *pL = NULL; /* on réinitialise la liste à vide */
 }
 int main(void) 
  {
    /* déclaration du pointeur sur tête de liste : */
    TypeCellule *L;
    L = SaisieListeEndroit(); /* on récupère l’adresse */
    /* de la première cellule */
    Affichage(L); /* on affiche la liste saisie */
    Liberation(&L); /* passage de l’adresse du pointeur */
    return 0;
  }
  