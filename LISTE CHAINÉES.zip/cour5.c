#include <stdio.h>
#include <stdlib.h>

typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 { 
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
    int a;
    float b;
    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
 }TypeCellule;

 void Affichage(TypeCellule* L)
  {
    TypeCellule *p;
    p=L; /* on pointe sur la première cellule */
    while (p != NULL) /* tant qu’il y a une cellule */
    {
        AfficheDonnee(p->donnee); /* on affiche la donnée */
        p = p->suivant; /* on passe à la cellule suivante */
    }
    puts(""); 
    /* passage à la ligne */
 }

 void AffichageBis(TypeCellule* L)
  {
    TypeCellule *p;/* tant qu’il y a une cellule */
    for (p=L ; p!=NULL ; p=p->suivant)
    AfficheDonnee(p->donnee); /* on affiche la donnée */
    puts(""); /* passage à la ligne */
  }
TypeCellule *InsereEnQueue(TypeCellule *L, TypeDonnee donnee)
 {
    TypeCellule *p, *nouveau;/* allocation d’une nouvelle cellule : */
    nouveau = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveau->donnee = donnee; /* donnée de la nouvelle cellule */
    nouveau->suivant = NULL; /* la nouvelle dernière cellule */
    if (L == NULL) /* cas particulier si la liste est vide */
    L = nouveau;
    else
    {/* recherche de la dernière cellule */
    for (p = L ; p->suivant!=NULL ; p=p->suivant)
    {}
     p->suivant = nouveau; /* chaînage */
    }
    return L;
 }


 TypeCellule* SaisieListeEndroit()
  {
    char choix;
    TypeDonnee donnee;/* déclaration d’une liste vide : */
    TypeCellule *L=NULL; /* initialisation obligatoire ! */
    puts("Voulez-vous entrer une liste non vide ?");
    choix = getchar();
    getchar();
    while (choix == 'o')
     {
        puts("Entrez une donnée");
        donnee = SaisieDonnee();
        getchar();
        L = InsereEnQueue(L, donnee); /* insertion en queue */
        puts("Voulez-vous continuer ?");
        choix = getchar();
        getchar();
     }
     return L;
}


  int main(void)
   {
    /* déclaration du pointeur sur tête de liste : */
    TypeCellule *L;
    L = SaisieListeEnvers(); /* on récupère l’adresse */
    /* de la première cellule */
    Affichage(L); /* on affiche la liste saisie */
    return 0;
   }

