#include <stdio.h>
#include <stdlib.h>

// Structure pour représenter chaque élément de la liste chaînée
struct Node {
    int data;
    struct Node* next;
};

// Fonction pour ajouter un nouvel élément à la fin de la liste
void append(struct Node** head_ref, int new_data) {
    // Allouer un nouveau nœud
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    struct Node* last = *head_ref;
    // Mettre les données dans le nouveau nœud
    new_node->data = new_data;
    // Le nouveau nœud sera le dernier de la liste, donc son pointeur next sera NULL
    new_node->next = NULL;
    // Si la liste est vide, le nouveau nœud devient la tête
    if (*head_ref == NULL) {
        *head_ref = new_node;
        return;
    }
    // Sinon, parcourir la liste jusqu'à atteindre le dernier nœud
    while (last->next != NULL) {
        last = last->next;
    }
    // Ajouter le nouveau nœud à la fin
    last->next = new_node;
    return;
}

// Fonction pour afficher les éléments de la liste
void printList(struct Node* node) {
    while (node != NULL) {
        printf("%d ", node->data);
        node = node->next;
    }
}

// Fonction principale pour tester le code
int main() {
    // Initialiser une liste vide
    struct Node* head = NULL;
    // Ajouter des éléments à la liste
    append(&head, 1);
    append(&head, 2);
    append(&head, 3);
    // Afficher les éléments de la liste
    printf("Liste chainee : ");
    printList(head);
    return 0;
}
