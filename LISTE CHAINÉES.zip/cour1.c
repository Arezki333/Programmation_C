#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* exemple : les données dans les cellules sont des float */
typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 { 
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
 }TypeCellule;
 
 
 int main(int argc, char const *argv[])
 {
    /* code */
    return 0;
 }
 