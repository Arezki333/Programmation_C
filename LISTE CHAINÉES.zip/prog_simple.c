#include <stdio.h>
#include <stdlib.h>

/* exemple : les données dans les cellules sont des float */
typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 {
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
    
    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
  }TypeCellule;

  TypeCellule *L; /* déclaration d’une liste */

 
 TypeDonnee SaisieDonnee()
  {
    TypeDonnee donnee;
    scanf("%f", &donnee); /* ici donnée est de type float */

    return donnee;
  } 

 
 void AfficheDonnee(TypeDonnee donnee)
 {
    printf("%f \n", donnee); /* ici donnée est de type float */
 }


  int main(void)
  { TypeDonnee a,b,c;
   
   a = SaisieDonnee();
   b = SaisieDonnee();
   c = SaisieDonnee();

    AfficheDonnee(a);
    AfficheDonnee(b);
    AfficheDonnee(c);

     
    return 0;
  }
  