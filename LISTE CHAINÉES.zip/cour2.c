#include <stdio.h>
#include <stdlib.h>


void AfficheDonnee(TypeDonnee donnee)
 {
    printf("%f ", donnee); /* ici donnée est de type float */
 }
 TypeDonnee SaisieDonnee(void)
  {
    TypeDonnee donnee;
    scanf("%f", &donnee); /* ici donnée est de type float */
    return donnee;
  }