#include <stdio.h>
#include <stdlib.h>

typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 { 
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
 }TypeCellule;

TypeCellule* InsereEnTete(TypeCellule *ancienL,TypeDonnee donnee)
 {
    TypeCellule *nouveauL; /* nouvelle tête de liste *//* création d’une nouvelle cellule */
    nouveauL = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveauL->donnee=donnee; /* on met la donnée à ajouter */
    /* dans la cellule */
    nouveauL->suivant=ancienL; /* chaînage */
    return nouveauL; /* on retourne la nouvelle tête de liste */
 }
 

TypeCellule* InsereEnTete(TypeCellule *ancienL,TypeDonnee donnee)
 {
    TypeCellule *nouveauL; /* nouvelle tête de liste *//* création d’une nouvelle cellule */
    nouveauL = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveauL->donnee=donnee; /* on met la donnée à ajouter */
    /* dans la cellule */
    nouveauL->suivant=ancienL; /* chaînage */
    return nouveauL; /* on retourne la nouvelle tête de liste */
 }

void AfficheDonnee(TypeDonnee donnee)
 {
    printf("%f ", donnee); /* ici donnée est de type float */
 }
 TypeDonnee SaisieDonnee(void)
  {
    TypeDonnee donnee;
    scanf("%f", &donnee); /* ici donnée est de type float */
    return donnee;
  }






TypeCellule* SaisieListeEnvers()
 {
    char choix;
    TypeDonnee donnee;/* déclaration d’une liste vide : */
    TypeCellule *L=NULL; /* initialisation obligatoire ! */
    puts("Voulez-vous entrer une liste non vide ?");
    choix = getchar();
    getchar();
    while (choix == 'o')
     {
        puts("Entrez une donnée");
        donnee = SaisieDonnee(); /* saisie au clavier */
        getchar();
        L = InsereEnTete(L, donnee); /* insertion en tête */
        /* ne pas oublier de récupérer la nouvelle tête dans L */
        puts("Voulez-vous continuer ?");
        choix = getchar();
        getchar();
    }
        return L;
            
 }

 

 int main(void)
 {
    SaisieListeEnvers();
    return 0;
 }
 