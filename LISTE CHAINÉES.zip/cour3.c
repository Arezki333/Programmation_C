#include <stdio.h>
#include <stdlib.h>

/* pour une insertion en téte de la liste */
TypeCellule* InsereEnTete(TypeCellule *ancienL,TypeDonnee donnee)
 {
    TypeCellule *nouveauL; /* nouvelle tête de liste *//* création d’une nouvelle cellule */
    nouveauL = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveauL->donnee=donnee; /* on met la donnée à ajouter */
    /* dans la cellule */
    nouveauL->suivant=ancienL; /* chaînage */
    return nouveauL; /* on retourne la nouvelle tête de liste */
 }

 int main(int argc, char const *argv[])
 {
    /* code */
    return 0;
 }
 