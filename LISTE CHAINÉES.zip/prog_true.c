#include <stdio.h>
#include <stdlib.h>

typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 { 
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
 

    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
   
 }TypeCellule;
TypeCellule *L; 
void AfficheDonnee(TypeDonnee donnee)
 {
    printf("%f ", donnee); /* ici donnée est de type float */
 }
 TypeDonnee SaisieDonnee(void)
  {
    TypeDonnee donnee;
    scanf("%f", &donnee); /* ici donnée est de type float */
    return donnee;
  }


 void Affichage(TypeCellule* L)
  {
    TypeCellule *p;
    p=L; /* on pointe sur la première cellule */
    while (p != NULL) /* tant qu’il y a une cellule */
    {
        AfficheDonnee(p->donnee); /* on affiche la donnée */
        p = p->suivant; /* on passe à la cellule suivante */
    }
    puts(""); 
    /* passage à la ligne */
 }

 void AffichageBis(TypeCellule* L)
  {
    TypeCellule *p;/* tant qu’il y a une cellule */
    for (p=L ; p!=NULL ; p=p->suivant)
    AfficheDonnee(p->donnee); /* on affiche la donnée */
    puts(""); /* passage à la ligne */
  }


 TypeCellule* SaisieListeEndroit()
  {
    char choix;
    TypeDonnee donnee;/* déclaration d’une liste vide : */
    TypeCellule *L=NULL; /* initialisation obligatoire ! */
    puts("Voulez-vous entrer une liste non vide ?");
    choix = getchar();
    getchar();
    while (choix == 'o')
     {
        puts("Entrez une donnée");
        donnee = SaisieDonnee();
        getchar();
        L = InsereEnQueue(L, donnee); /* insertion en queue */
        puts("Voulez-vous continuer ?");
        choix = getchar();
        getchar();
     }
     return L;
}


void Liberation(TypeCellule **pL)/* passage d’un pointeur par adresse : */
/* pointeur sur pointeur */
 {
    TypeCellule *p;
    while (*pL != NULL) /* tant que la liste est non vide */
     {
        p = *pL; /* mémorisation de l’adresse de la cellule */
        *pL = (*pL)->suivant; /* cellule suivante */
        free(p); /* destruction de la cellule mémorisée */
     }
     *pL = NULL; /* on réinitialise la liste à vide */
 }
 int main(void) 
  {
    /* déclaration du pointeur sur tête de liste : */
    TypeCellule *L;
    L = SaisieListeEndroit(); /* on récupère l’adresse */
    /* de la première cellule */
    Affichage(L); /* on affiche la liste saisie */
    Liberation(&L); /* passage de l’adresse du pointeur */
    return 0;
  }