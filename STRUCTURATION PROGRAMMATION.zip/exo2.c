#include <stdio.h>
float moyenne(float a, float b, float c)
 {
    return (a + b + c) / 3.0;
 }
 
 
 int main(void)
  {
    float n1, n2, n3;
    printf("Entrez trois nombres : ");
    scanf("%f %f %f", &n1, &n2, &n3);
    printf("La moyenne des nombres vaut %f\n", moyenne(n1, n2, n3));
    return 0;
  }