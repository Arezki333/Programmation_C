#include <stdio.h>
void afficheASCII(char caractere)
 {
    printf("Code ASCII = %d\n", caractere);
 }
 
 int main(void)
  {
    char c;
    printf("Entrez un caractère : ");
    c=(char) getchar();
    afficheASCII(c);
    return 0;
  }