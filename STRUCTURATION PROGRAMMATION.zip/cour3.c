#include <stdio.h>
#include <math.h> /* pour la fonction sinus */
int main()
 {
    float x, y; /* on calcule y=f(x) */
    puts("Veuillez taper une valeur de x :");
    scanf("%f", &x);
    y = (x*x*x-2*x+1)*sin(3*x+1);
    printf("on a : f(%f) = %f", x, y);
    return 0;
 }