#include <stdio.h>

float Impot(float R, int n)
 {
    if (R / n < 500.0)
    return 0.1 * R;
    else
    return 0.2 * R;
 }

 float RevenuNet(float R, int n)
  {
    return R - Impot(R, n);
  }

int main(void)
{   float x, y;
    puts("entrer les données pour le calcule des impots :");
    scanf("%f %f",&x, &y);
    Impot(x,y);
    RevenuNet(x,y);
    printf("voici le l'impot = %f\n et voici aussi le revenunet =%f\n ",Impot(x,y),RevenuNet(x,y));
 
    return 0;
}
