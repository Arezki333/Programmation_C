#include <stdio.h>
int Puissance7(int a) /* prototype de la fonction */
 {
    int resultat; /* variable locale */
    resultat = a*a*a*a*a*a*a; /* calcul de a7*/
    return resultat; /* on renvoie le résultat */
}
/* Exemple d’utilisation dans le main : */
int main(void)
 {
    int n, puiss7; /* variables du main */
    printf("Veuillez entrer n");
    scanf("%d", &n); /* lecture de n */
    puiss7 = Puissance7(n); /* appel de la fonction *//* on récupère le résultat dans la variable puiss7 */
    printf("n puissance 7 est égal à %d\n", puiss7);
    return 0;
 }