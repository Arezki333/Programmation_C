#include <stdio.h>

int Puissance7bis(int n) /* prototype de la fonction */
 {
    int resultat, n2; /* variables locales */
    n2 = n*n; /* calcul de n2*/
    resultat = n2*n2*n2*n; /* calcul de n7*/
    return resultat; /* on renvoie le résultat */
 }

 int main(void)
 {
    int n, puiss7; /* variables du main */
    printf("Veuillez entrer n");
    scanf("%d", &n); /* lecture de n */
    puiss7 = Puissance7bis(n); /* appel de la fonction *//* on récupère le résultat dans la variable puiss7 */
    printf("n puissance 7 est égal à %d\n", puiss7);
    return 0;
 }