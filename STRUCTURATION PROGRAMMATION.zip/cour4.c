#include <stdio.h>
#include <math.h>

/* Fonction Lire, permet de lire une valeur */
float Lire(void) /* La fonction lire retourne un float */
 {
    float d; /* déclaration d’une variable locale d */
    puts("Veuillez taper une valeur :");
    scanf("%f", &d); /* on lit la valeur de d */
    return d; /* on renvoie la valeur de d */
 }
 
 /* Fonction CalculF, calcule une valeur de la fonction */
  float CalculF(float x) /* renvoie f(x) pour x float */
  {
    return (x*x*x-2*x+1)*sin(3*x+1);
  }
  
  /* Fonction Affiche, permet d’afficher une valeur */
    void Affiche(float y) /* affiche une valeur float y */
   {
    printf("La valeur calculée est %f\n", y);/* une fonction void ne retourne rien */
   }
  
   /* Fonction main, programme principal */
   int main()
    {
        float x, y; /* on calcule y=f(x) */
        x = Lire(); /* appel de la fonction Lire */
        y = CalculF(x); /* calcul de f(x) */
        Affiche(y); /* appel de la fonction Affiche */
        return 0;
    }