#include <stdio.h>
void NeModifiePas(int x)
 {
    x=2; /* le x local est modifiée, pas le x du main */
 }
 
 int main(void)
  {
    int x=1;
    NeModifiePas(x);
    printf("%d", x); /* affiche 1 (valeur inchangée) */
  }