#include <stdio.h>
void aire(float base, float hauteur)
 {
    printf("Aire = %f\n", (base * hauteur) / 2.0);
 }
 
 int main(void)
  {
    float b, h;
    printf("Entrez la base et la hauteur du triangle : ");
    scanf("%f %f", &b, &h);
    aire(b, h);
    return 0;
  }