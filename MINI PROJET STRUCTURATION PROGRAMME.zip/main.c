#include <stdio.h>
#include <math.h>
#include "headr.h"

int main(void)
{  float x;
   int sig;
    choix();
    printf("voici le signe de la derivee seconde de f \n");
    printf("entrer la valeur de x!!:\n");
    scanf("%f",&x); 
     sig = signe(x);
     if (sig ==-1)
        printf("valeur negative \n");
        else if (sig==0)
        printf("valeur null\n");
        if (sig==1)
        printf("valeur positiv\n");
            
    return 0;
}
