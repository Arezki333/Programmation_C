#include <stdio.h>
#include <math.h>
#include "headr.h"

float f(float x)
 {
    return ((2 * x*x*x+3)*(x*x-1))/sqrt(3 * x * x + 1);
 }
 
float fPrime(float x, float h)
 {
    return (f(x + h) - f(x - h)) / (2 * h);
 }

 float fSeconde(float x, float h)
  {
    return (fPrime(x + h, h) - fPrime(x - h, h)) / (2 * h);
  }

  int signe(float x)
   { 
    float h, dSeconde;
    printf("Donnez le pas d’approximation h : ");
    scanf("%f", &h);
    dSeconde = fSeconde(x, h);
    if (dSeconde < 0.0)
     return -1;
    if (dSeconde == 0.0)
     return 0;
    return 1;
}

void choix()
 {
    int sign,c;
    float x, h;
    printf("Voulez-vous...\n");
    printf("1 la valeur de f  \n");
    printf("2 la valeur de f’\n");
    printf("3 la valeur de f’’\n");
    
    c = getchar();
    printf("x = ? ");
    scanf("%f", &x);
    switch (c)
     {
        case '1':printf("f(%f) = %f\n", x, f(x));
                 break;
        case '2':printf("h = ? ");
                 scanf("%f", &h);
                 printf("f’(%f) = %f\n", x, fPrime(x, h));
                 break;
        case '3':printf("h = ? ");
                 scanf("%f", &h);
                 printf("f’’(%f) = %f\n", x, fSeconde(x, h));
                 break;
     

        default:printf("Choix inconnu...\n");
        }
 }