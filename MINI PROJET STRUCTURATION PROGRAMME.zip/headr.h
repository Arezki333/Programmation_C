

float f(float x);
float fPrime(float x, float h);
float fSeconde(float x, float h);
int signe(float x);
void choix();



