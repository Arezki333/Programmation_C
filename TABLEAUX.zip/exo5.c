#include <stdio.h>
#define NB_MAX 100
void insertion(int t[NB_MAX], int n, int i, int m)
 {
    int j=n;
    while (j > i)
     {
        t[j] = t[j - 1];
        j--;
     }
   t[i] = m;
 }

  int SaisieTableau(int tableau[NB_MAX])
 {
    int n, i;puts("Entrez le nombre d’éléments du tableau : ");
    scanf("%d", &n);
    if (n > NB_MAX)
     {
        puts("Erreur : le tableau est trop petit");
        return -1; /* retour d’un code d’erreur */
     }
     puts("Entrez un à un les éléments");
     for (i=0 ; i<n ; i++)
     scanf("%d", &tableau[i]);
     return n;
 }
 void Affichage(int tableau[], int n)
 {
    int i;
    for (i=0 ; i<n ; i++)
     {
        printf("l’élément numéro %d vaut %d\n", i, tableau[i]);
     }
 }

  int main()
  {
    int n,m,k ,reslt; /* nombre d’éléments */
    int tableau[NB_MAX]; /* déclaration du tableau */
    n = SaisieTableau(tableau);
    if (n > 0) /* Test d’erreur */
    printf("entrer le nombre à saisir dans le tableau en 1er puis son indexe en 2éme :");
    scanf("%d %d",&m, &k);
    Affichage(tableau,n);
    printf("\n");
    insertion(tableau,n,k,m);
    printf("\n");
    Affichage(tableau,n);
 
    return 0;
  }





     

    