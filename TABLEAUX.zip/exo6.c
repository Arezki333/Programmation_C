#include <stdio.h>
#define NB_MAX 31

void remplir(unsigned int t[NB_MAX])
 {
    int i=1;
    t[0] = 1;
    while (i < NB_MAX)
    {t[i] = t[i - 1] * 2;
    i++;
    }
    
 }

 void clavier()
  {
    char c;
    int choix, i = 0;
    unsigned int n;
    unsigned int t[NB_MAX];
    remplir(t);
    while (!0)
     {
        choix = 0;
        printf("Entrez 0 ou 1 : ");
        while (!choix)
        {
        c = getchar();
        choix = ((c == '0') || (c == '1'));
        }
      if (c == '1')
      n += t[i];
      i++;
      printf("Valeur courante : %d\n", n);
      }
}

 void Affichage(int tableau[], int n)
 {
    int i;
    for (i=0 ; i<n ; i++)
     {
        printf("l’élément numéro %d vaut %d\n", i, tableau[i]);
     }
 }



int SaisieTableau(int tableau[NB_MAX])
 {
    int n, i;puts("Entrez le nombre d’éléments du tableau : ");
    scanf("%d", &n);
    if (n > NB_MAX)
     {
        puts("Erreur : le tableau est trop petit");
        return -1; /* retour d’un code d’erreur */
     }
     puts("Entrez un à un les éléments");
     for (i=0 ; i<n ; i++)
     scanf("%d", &tableau[i]);
     return n;
 }
 
  int main()
  {
    int n; /* nombre d’éléments */
    int tableau[NB_MAX]; /* déclaration du tableau */
    n = SaisieTableau(tableau);
    if (n > 0) /* Test d’erreur */
    Affichage(tableau,n);
    printf("\n");
    remplir(tableau);
    printf("\n");
    Affichage(tableau,n);
    clavier();
 
    return 0;
  }





     
