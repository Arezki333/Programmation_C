#include <stdio.h>
#define NB_ELEM_MAXI 100
void afficheImpair(float t[NB_ELEM_MAXI], int taille)
 {
    int i;
    for (i = 1; i < taille; i += 2)
    printf("t[%d] = %f\n", i, t[i]);
 }

int SaisieTableau(float tableau[NB_ELEM_MAXI])
 {
    int n, i;puts("Entrez le nombre d’éléments du tableau : ");
    scanf("%d", &n);
    if (n > NB_ELEM_MAXI)
     {
        puts("Erreur : le tableau est trop petit");
        return -1; /* retour d’un code d’erreur */
     }
     puts("Entrez un à un les éléments");
     for (i=0 ; i<n ; i++)
     scanf("%f", &tableau[i]);
     return n;
 }

  int main()
  {
    int n; /* nombre d’éléments */
    float tableau[NB_ELEM_MAXI]; /* déclaration du tableau */
    n = SaisieTableau(tableau);
    if (n > 0) /* Test d’erreur */
    afficheImpair(tableau, n); /* Affichage du tableau */
    return 0;
  }
