#include <stdio.h>
#define NB_ELEM 15 /* Nombre d’éléments du tableau */
/* ******** Fonction Affichage ********** */
/* Affiche un tableau */
void Affichage(float tableau[NB_ELEM])
 {
    int i;
    for (i=0 ; i<NB_ELEM ; i++)
     {
        printf("l’élément numéro %d vaut %f\n", i, tableau[i]);
     }
 }

 /* ********* Fonction main ********** */
 /* Lit un tableau et le fait afficher */
 
 int main()
  {
    int i; /* indice */
    float tableau[NB_ELEM]; /* déclaration du tableau */
    for (i=0 ; i<NB_ELEM ; i++)
     {
        printf("Entrez l’élément %d : ", i);
        scanf("%f", &tableau[i]); /* lecture d’un élément */
     }
     
     Affichage(tableau); /* Affichage du tableau */
     return 0;
  }