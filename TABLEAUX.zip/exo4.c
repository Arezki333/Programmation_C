#include <stdio.h>
#define NB_ELEM_MAXI 100
char recherche(int t[NB_ELEM_MAXI], int taille, int m)
 {
    int i;
    for (i = 0; i < taille; i++)
    { 
        if (t[i] == m)
        return 1;
    }
       return 0;
 }

 int SaisieTableau(int tableau[NB_ELEM_MAXI])
 {
    int n, i;puts("Entrez le nombre d’éléments du tableau : ");
    scanf("%d", &n);
    if (n > NB_ELEM_MAXI)
     {
        puts("Erreur : le tableau est trop petit");
        return -1; /* retour d’un code d’erreur */
     }
     puts("Entrez un à un les éléments");
     for (i=0 ; i<n ; i++)
     scanf("%d", &tableau[i]);
     return n;
 }

  int main()
  {
    int n,m, reslt; /* nombre d’éléments */
    int tableau[NB_ELEM_MAXI]; /* déclaration du tableau */
    n = SaisieTableau(tableau);
    if (n > 0) /* Test d’erreur */
    printf("entrer un nombre pour voir si le nombre entrer est dans le tableau :");
    scanf("%d",&m);
    reslt = recherche(tableau,n,m);
    if (reslt == 1)
    printf("oui le nombre entrer est dans le tableau \n");
    else
    printf("le nombre entrer n'est pas dans le tableau \n");         
    return 0;
  }





     

    