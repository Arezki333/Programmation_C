#include <stdio.h>
#define NB_ELEM_MAXI 100 /* Nombre maximum d’éléments *//* du tableau */
/* ******** Fonction Affichage ********** */
/* Affiche un tableau de taille n */
void Affichage(float tableau[], int n)
 {
    int i;
    for (i=0 ; i<n ; i++)
     {
        printf("l’élément numéro %d vaut %f\n", i, tableau[i]);
     }
 }

 /* ********* Fonction main ********** */
 /* Lit un tableau et le fait afficher */
 int main()
  {
    int n, i; /* nombre d’éléments et indice */
    float tableau[NB_ELEM_MAXI]; /* déclaration du tableau */
    printf("Entrez le nombre d’éléments à taper : ");/* lecture du nombre d’éléments au clavier (variable) */
    scanf("%d", &n);
    if (n > NB_ELEM_MAXI)
     {
         /* test d’erreur */
         puts("Erreur, nombre trop grand !");
         return 1;
     }
     
     for (i=0 ; i<n ; i++)
      { /* n éléments */
      printf("Entrez l’élément %d : ", i);
      scanf("%f", &tableau[i]); /* lecture d’un élément */
      }
      
      Affichage(tableau, n); /* Affichage du tableau */
      return 0;
    }

    