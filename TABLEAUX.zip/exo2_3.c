#include <stdio.h>
#define NB_ELEM_MAXI 100
int max(int t[NB_ELEM_MAXI], int taille)
 {
    int i;
    int max = t[0];
    for (i = 1; i < taille; i++)
     {
        if (max < t[i])
        max = t[i];
     }
     return max;
 }


 int somme(int t[NB_ELEM_MAXI], int taille)
  {
    int i;
    int somme = t[0];
    for (i = 1; i < taille; i++)
    somme += t[i];
    return somme;
  }


int SaisieTableau(int tableau[NB_ELEM_MAXI])
 {
    int n, i;puts("Entrez le nombre d’éléments du tableau : ");
    scanf("%d", &n);
    if (n > NB_ELEM_MAXI)
     {
        puts("Erreur : le tableau est trop petit");
        return -1; /* retour d’un code d’erreur */
     }
     puts("Entrez un à un les éléments");
     for (i=0 ; i<n ; i++)
     scanf("%d", &tableau[i]);
     return n;
 }

  int main()
  {
    int n,maxi,som; /* nombre d’éléments */
    int tableau[NB_ELEM_MAXI]; /* déclaration du tableau */
    n = SaisieTableau(tableau);
    if (n > 0) /* Test d’erreur */
  
      maxi = max(tableau,n);
      som = somme(tableau,n);
      
      printf("voici le maximum du tableau :  %d \n et voici aussi la somme totale du tableau : %d  \n",maxi, som);

    return 0;
  }





     

    