#include <stdio.h>
#include <stdlib.h>

/* exemple : les données dans les cellules sont des float */
typedef float TypeDonnee;
/* définition du type cellule : */
typedef struct Cell
 {
    TypeDonnee donnee; /* définition des données */
    /* on peut mettre ce qu’on veut comme donnée */
    
    struct Cell *suivant; /* pointeur sur la structure suivante */
    /* (de même type que celle qu’on est en train de définir) */
  }TypeCellule;

  TypeCellule *L; /* déclaration d’une liste */

 /*--------------------les fonctions-----------------------------------*/
 TypeDonnee SaisieDonnee()
  {
    TypeDonnee donnee;
    scanf("%f", &donnee); /* ici donnée est de type float */

    return donnee;
  } 

TypeCellule* InsereEnTete(TypeCellule *ancienL,TypeDonnee donnee)
 {
    TypeCellule *nouveauL; /* nouvelle tête de liste */
    /* création d’une nouvelle cellule */
    nouveauL = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveauL->donnee=donnee; /* on met la donnée à ajouter */
    /* dans la cellule */
    nouveauL->suivant=ancienL; /* chaînage */
    return nouveauL; /* on retourne la nouvelle tête de liste */
 }
 TypeCellule* SaisieListeEnvers()
  {
    char choix;
    TypeDonnee donnee;/* déclaration d’une liste vide : */
    TypeCellule *L=NULL; /* initialisation obligatoire ! */
    puts("Voulez-vous entrer une liste non vide ?");
    choix = getchar();
    getchar();
    while (choix == 'o')
     {
        puts("Entrez une donnée");
        donnee = SaisieDonnee(); /* saisie au clavier */
        getchar();
        L = InsereEnTete(L, donnee); /* insertion en tête */
        /* ne pas oublier de récupérer la nouvelle tête dans L */
        puts("Voulez-vous continuer ?");
        choix = getchar();
        getchar();
     }
     return L;
  }


TypeCellule *InsereEnQueue(TypeCellule *L, TypeDonnee donnee)
 {
    TypeCellule *p, *nouveau;/* allocation d’une nouvelle cellule : */
    nouveau = (TypeCellule*)malloc(sizeof(TypeCellule));
    nouveau->donnee = donnee; /* donnée de la nouvelle cellule */
    nouveau->suivant = NULL; /* la nouvelle dernière cellule */
    if (L == NULL) /* cas particulier si la liste est vide */
    L = nouveau;
    else
    {/* recherche de la dernière cellule */
    for (p = L ; p->suivant!=NULL ; p=p->suivant)
    {}
     p->suivant = nouveau; /* chaînage */
    }
    return L;
 }

 TypeCellule* SaisieListeEndroit()
  {
    char choix;
    TypeDonnee donnee;/* déclaration d’une liste vide : */
    TypeCellule *L=NULL; /* initialisation obligatoire ! */
    puts("Voulez-vous entrer une liste non vide ?");
    choix = getchar();
    getchar();
    while (choix == 'o')
     {
        puts("Entrez une donnée");
        donnee = SaisieDonnee();
        getchar();
        L = InsereEnQueue(L, donnee); /* insertion en queue */
        puts("Voulez-vous continuer ?");
        choix = getchar();
        getchar();
     }
     return L;
}



 
 void AfficheDonnee(TypeDonnee donnee)
 {
    printf("%f \n", donnee); /* ici donnée est de type float */
 }

 void Affichage(TypeCellule* L)
  {
    TypeCellule *p;
    p=L; /* on pointe sur la première cellule */
    while (p != NULL) /* tant qu’il y a une cellule */
    {
        AfficheDonnee(p->donnee); /* on affiche la donnée */
        p = p->suivant; /* on passe à la cellule suivante */
    }
    puts(""); 
    /* passage à la ligne */
 }

 void AffichageBis(TypeCellule* L)
  {
    TypeCellule *p;/* tant qu’il y a une cellule */
    for (p=L ; p!=NULL ; p=p->suivant)
    AfficheDonnee(p->donnee); /* on affiche la donnée */
    puts(""); /* passage à la ligne */
  }


void Liberation(TypeCellule **pL)/* passage d’un pointeur par adresse : */
/* pointeur sur pointeur */
 {
    TypeCellule *p;
    while (*pL != NULL) /* tant que la liste est non vide */
     {
        p = *pL; /* mémorisation de l’adresse de la cellule */
        *pL = (*pL)->suivant; /* cellule suivante */
        free(p); /* destruction de la cellule mémorisée */
     }
     *pL = NULL; /* on réinitialise la liste à vide */
 }

/*----------------fonction pour la sommes des elements de la chaine */

int Somme(TypeCellule * L)
 {
   TypeCellule *p;
   int somme = 0;
   p=L;
   while (p != NULL)
    {
      somme += p->donnee;
      p = p->suivant;
    }
    return somme;
  }
/*------------fonction pour la recherche d'un element dans la chaine*/
TypeCellule *Recherche(TypeCellule * L, TypeDonnee n)
 {
   TypeCellule *p;
   p=L;
   while (p != NULL && p->donnee != n)
   p = p->suivant;
   if (p == NULL)
   return NULL;
   return p;
 }



/*-----------------------le main *-------------------------------*/
 
  int main(void)
   {
    
    /* déclaration du pointeur sur tête de liste : */
    TypeCellule *L ;
    L = SaisieListeEndroit(); /* on récupère l’adresse */
    /*L = SaisieListeEnvers();*/
   
    /* de la première cellule */
    Affichage(L); /* on affiche la liste saisie */
    printf("voici la somme de la chaine %d\n",Somme(L));
    printf("voici le resultat de la recherche : %p\n", Recherche(L,3));
    Liberation(&L); /* passage de l’adresse du pointeur */
    return 0;
  }
  