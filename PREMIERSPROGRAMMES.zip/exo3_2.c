#include <stdio.h>
int main(void)
 {
    float x, h, fx, fx_plus_h, fPrime_x;
    printf("Entrez un nombre : ");
    scanf("%f", &x);
    printf("Entrez un écart h : ");
    scanf("%f", &h);
    fx = (2.0 * x + 3.0) / (3.0 * x * x + 2.0);
    fx_plus_h = (2.0 * (x + h) + 3.0) / (3.0 * (x + h) * (x + h) + 2.0);
    fPrime_x = (fx_plus_h - fx) / h;
    printf("f’(%f) = %f\n", x, fPrime_x);
    return 0;
 }