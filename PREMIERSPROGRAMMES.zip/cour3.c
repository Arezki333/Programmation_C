#include <stdio.h> /* pour pouvoir lire et écrire */
int main(void) /* programme principal */
 {
    float x, y; /* déclaration de deux variables x et y */
    printf("Veuillez entrer un nombre réel au clavier\n");
    scanf("%f", &x); /* lecture au clavier de la valeur de x */
    y = 2*x; /* on met dans y le double du contenu de x */
    printf("Le double du nombre tapé vaut %f \n", y);
    return 0;
 }