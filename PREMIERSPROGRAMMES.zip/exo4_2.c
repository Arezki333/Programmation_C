#include <stdio.h>
#include <math.h>
int main(void)
 {
    float h, t;
    printf("Entrez la hauteur totale (en mètres) : ");
    scanf("%f", &h);
    t = sqrt(2.0 * h / 9.81);
    printf("La bille touche le sol au bout de %f secondes\n", t);
    return 0;
 }