 #include <stdio.h>
 int main(void)
 
  {
    float h, t; 
    printf("Entrez une durée : ");
    scanf("%f", &t);
    h = (9.81 * t * t) / 2.0;
    printf("A t = %f, h = %f\n", t, h);
    return 0;
  }