#include <stdio.h>
int main(void)
 {
    float celsius, fahrenheit;
    printf("Entrez une température en degrés Celsius : ");
    scanf("%f", &celsius);
    fahrenheit = (celsius / 0.55556) + 32.0;
    printf("Température de %f degré Fahrenheit.\n", fahrenheit);
    return 0;
 }