#include <stdio.h>
int main(void)
 {
    float x, fx;
    printf("Entrez un nombre : ");
    scanf("%f", &x);
    fx = (2.0 * x + 3.0) / (3.0 * x * x + 2.0);
    printf("f(%f) = %f\n", x, fx);
    return 0;
 }