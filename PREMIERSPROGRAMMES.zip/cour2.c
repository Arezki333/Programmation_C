#include <stdio.h> /* pour pouvoir lire et écrire */
 int main(void) /* programme principal */
  {
    float x; /* déclaration d’une variable x (nombre réel) */
    printf("Veuillez entrer un nombre réel au clavier\n");
    scanf("%f", &x); /* lecture au clavier de la valeur de x */ 
    /* affichage de x : */
    printf("Vous avez tapé %f, félicitations !\n", x);
    return 0;
  }