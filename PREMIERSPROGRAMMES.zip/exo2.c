#include <stdio.h>
int main(void) 
 {
    float prix, prixRemise;
    printf("Entrez un prix : ");
    scanf("%f", &prix);
    prixRemise = 0.9 * prix;
    printf("Le prix avec 10 %% de remise est de %f.\n", prixRemise);
    return 0;
 }