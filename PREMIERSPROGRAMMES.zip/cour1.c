#include <stdio.h> /* pour pouvoir lire et écrire */
int main(void) /* programme principal */
 {
    printf("Bonjour !\n"); /* écriture à l’écran */
    return 0;
 }
