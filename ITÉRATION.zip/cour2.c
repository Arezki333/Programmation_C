#include <stdio.h>
int PuissanceBis(int n, int k)
 {
    int i; /* plus d’initialisation ici */
    int resultat = 1; /* initialisation à 1 (calcul du produit) */
    for (i=0 ; i < k ; i=i+1) /* boucle for */
    { 
        resultat = resultat*n;
     }
return resultat;
}

int main(void)
{
   int n,k,rsult;
   printf("entrer la puissance à calculer  : \n");
   scanf("%d",&k);
   printf("entrer un nombre :\n");
   scanf("%d",&n);
   rsult =  PuissanceBis(n,k);
   printf("voici le resultat :%d \n",rsult);
    return 0;
}
