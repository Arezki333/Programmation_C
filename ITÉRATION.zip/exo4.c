#include <stdio.h>
int base10(int n)
 {
    int nombre = 0;
    while (n > 0)
     {
        n = n / 10;
        nombre = nombre + 1;
     }
     return nombre;
 }

 int base10i(int n, int i)
  {
    while (i > 0)
     {
        n = n / 10;
        i=i-1;
     }
     return n % 10;
  }

    int main(void)
{
   int n,i;
   printf("calcule le nombre de chiﬀres en base 10 d’un nombre n : ");
   scanf("%d",&n);
   printf("\n");
   printf("calcule le ième chiﬀre en base 10 d’un nombre n  \n");
   printf("entrer le nombre de la iéme  i : ");
   scanf("%d",&i);
   printf("\n");
   printf("voici le resultat de la base 10:%d \n",base10(n));
   printf("voici le resultat de la iéme base10i  :%d \n",base10i(n,i));
   return 0;
}
