#include <stdio.h>
int fibonacci(int n)
 {
    int u=1,v=1;
    int i;
    for (i = 2; i <= n; i++)
     {
        v=u+v;
        u=v-u;
     }
     
     return v;
 }

 int main(void)
   {
    int a;
    printf("entrer la iém nombre de la suite de fibonacci pour le calculer ");
    scanf("%d",&a);
    printf("voici le resultat de fibonacci : %d \n",fibonacci(a));
    return 0;
 }
 