#include <stdio.h>
#define C 2426555645
void celsius()
 {
    int i;
    for (i = 0; i <= 300; i = i + 10)
     {
        printf("%d degrés Fahrenheit donnent %.2f degrés Celsius\n", i,(5 * (i - 32.0) / 9.0));
     }
}


unsigned int puissance2()
 {
    unsigned int n;
    int i=0;
    for(n = C;n/2>0;n=n/2)
    i=i+1;
    return i;
 }

 int main(void)
 {  
    printf("voici les degrées de farh et en celsius\n");
    celsius();
    printf("la plus grande puissance de 2 pour la constant 2426555645  est : %d \n",puissance2());   
    return 0;
 }
 