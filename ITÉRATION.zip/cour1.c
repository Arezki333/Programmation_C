#include <stdio.h>
int Puissance(int n, int k)
 {
    int i=0; /* initialisation obligatoire */
    int resultat = 1; /* initialisation à 1 (calcul du produit) */
    while (i < k) /* boucle tant que */
     {
        resultat = resultat*n;
        i = i+1; /* progression obligatoire */
     }
     return resultat;
}

int main(void)
{int n,k,rsult;
   printf("entrer la puissance à calculer  : \n");
   scanf("%d",&k);
   printf("entrer un nombre :\n");
   scanf("%d",&n);
   rsult =  Puissance(n,k);
   printf("voici le resultat :%d \n",rsult);
    return 0;
}
