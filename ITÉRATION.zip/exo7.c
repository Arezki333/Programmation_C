#include <stdio.h>
#include<math.h>

float un(unsigned int n)
 {
    float u = 1.0;
    unsigned int i;
    for (i = 1; i <= n; i++)
    u = 2 * sqrt(u + 1) - 1;
    return u;
 }

 int main(void)
 {  int n;
    printf("le calcule d'une suite avec un nombre saisie :");
    scanf("%d",&n);
    printf("\n");
    printf("voici le resultat : %f\n",un(n));
    return 0;
 }
 