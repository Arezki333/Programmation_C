#include <stdio.h>

void voter()
 {
    int nVotantA = 0, nVotantB = 0;
    char c;
    int stop = 0, choix; /* 0 <-> faux; !0 <-> vrai */
    float voix;
    while (!stop)
     {
        choix = 0;
        printf("On continue (o/n) ? ");
        while (!choix)
         {
            c=(char) getchar();
            choix = (c == 'o') || (c == 'n');
         }
         
         if (c == 'o')
          {
            choix = 0;
            printf("Vote pour A ou pour B ? ");
            while (!choix)
             {
                c = getchar();
                choix = (c == 'A') || (c == 'B');
             }
             if (c == 'A')
             nVotantA = nVotantA + 1;
             else
             nVotantB = nVotantB + 1;
             }
             else
             stop = !stop;
             }
             if 
             (nVotantA + nVotantB > 0)
             {
                voix = (100.0 * nVotantA) / (float) (nVotantA + nVotantB);
                printf("A a obtenu %f %% des voix et B a obtenu %f %% des voix\n",voix, 100 - voix);
                if (nVotantA > nVotantB)
                printf("A est élu\n");
                if (nVotantA < nVotantB)printf("B est élu\n");
                if (nVotantA == nVotantB)
                printf("Aucun élu\n");
             }
    }

int main(void)
{   printf("bienvenu dans la paltform des elections 2023\n");
    voter();
    return 0;
}
