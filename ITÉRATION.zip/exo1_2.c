#include <stdio.h>
int fact(int n)
 {
    int f=1;
    while (n > 0)
     {
        f=f*n;
        n=n-1;
     }
     return f;
 }

 int cube(int n)
  {
    int s=0;
    while (n > 0)
     {
        s=s+n*n*n; 
        n=n-1;
     }
     return s;
  }

  int main(void)
{
   int n,rsult1, rsult2;
   printf("entrer le nombre dont vous voulez calculez le factoriel et lé somme au cube : \n");
   scanf("%d",&n);
   rsult1 =  fact(n);
   rsult2 = cube(n);
   printf("voici le resultat du factorirl :%d \n",rsult1);
   printf("voici le resultat de la somme au cube  :%d \n",rsult2);

    return 0;
}
