#include <stdio.h>
#include <math.h>
double f(int n)
 {
    return (150 * sin(n)) / (double) (1 + n);
 }
 
 double max(int N)
  {
    int i;
    double fi, 
    maxi = f(0);
    for (i = 1; i < N; i++)
     {
        fi = f(i);
        if (fi > maxi)
        maxi = fi;
     }
     return maxi;
  }

  int nombre(int N, double a)
   {
    int i, nb;
    double fi;
    nb = 0;
    for (i = 0; i < N; i++)
     {
        fi = f(i);
        if (fabs(fi) <= a)
        nb++;
     }
     return nb;
   }

   int main(void)
   {int x;
    double a;
    printf(" pour trouver le max de la fonction f ");
    scanf("%d",&x);
    printf("pour trouver le nombre de valeur entre -a et a entrer a la fonction f ");
    scanf("%lf",&a);
    printf("\n");
    printf("voici le maximum de f : %lf \n et aussi le nombre de valeur dans l'intervale [-a,a] : %d \n",max(x),nombre(x,a) );

    return 0;
   }
   