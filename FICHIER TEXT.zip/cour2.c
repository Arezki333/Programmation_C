#include <stdio.h> 

int TripleFichier(void)
 {
    FILE *fpr, *fpw; /* deux pointeurs pour deux fichiers */
    int n; /* pour lire */
    fpr = fopen("fichierLecture.txt", "rt");
    fpw = fopen("fichierEcriture.txt", "w"); /*j'ai supprimer le r puis mainteant sa marche */
    if (fpr==NULL || fpw==NULL) /* gestion d’erreur */
    return 1; /* code d’erreur retourné au main */
    while (fscanf(fpr, "%d", &n)==1) /* lecture d’un entier */
    fprintf(fpw, "%d ", 3*n); /* écriture du triple */
    fclose(fpr); /* fermeture des deux fichiers */
    fclose(fpw);
    return 0; /* pas d’erreur */
 }

 
 
 int main() 
 {
    int codeErr;
    codeErr = TripleFichier();/* on récupère le code d’erreur dans le main : */
    if(codeErr != 0)
    puts("Erreur d’ouverture de fichier !");
    else
    puts(" no problem");
    return 0;
 }



