#include <stdio.h> 
#include <stdlib.h> /* pour utiliser la fonction exit */
#define NB_ELEM_MAX 100

int ChargeFichier(int tableau[NB_ELEM_MAX])
 {
    FILE *fp;
    int i=0;/* ouverture du fichier : */
    fp = fopen("arezki_1.txt", "rt");
    if (fp ==NULL) /* gestion d’erreur */
     {
        puts("Erreur d’ouverture de fichier :");
        puts("Fichier inexistant ou permissions insuffisantes");
        exit(1); /* termine le programme avec code d’erreur */
     }
     /* on peut mettre des appels de fonctions comme fscanf dans une condition. Ici, fscanf retourne 1 en cas de succès */
     while (i < NB_ELEM_MAX && fscanf(fp, "%d", &tableau[i])==1)
     i++; /* incrémentation : pareil que i=i+1 */
     fclose(fp); /* fermeture du fichier */
     return i; /* on retourne le nombre d’éléments lus */
 }
 
 void Affiche(int tableau[], int n)
  {
    int i;
    for (i=0 ; i<n ; i++)
    printf("tableau[%d] = %d\n", i, tableau[i]);
  }
   
   
   
int main()
     {
        int tab[NB_ELEM_MAX];
        int n;
        n = ChargeFichier(tab);
        Affiche(tab, n);
        return 0;
     }