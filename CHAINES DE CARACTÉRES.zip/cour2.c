#include <stdio.h>
int main(void)
 {
    char chaine[100];
    puts("Veuillez entrer un mot");
    scanf("%s", chaine);
    printf("Vous avez entré : %s\n", chaine);
    return 0;
 }