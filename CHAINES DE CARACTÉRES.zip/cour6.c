#include <stdio.h>
#include <string.h>
int main(void)
 {
    char chaine[100], mot1[50], mot2[51];
    puts("Veuillez saisir un mot (au plus 49 lettres)");
    scanf("%s", mot1);
    puts("Veuillez saisir un autre mot (au plus 50 lettres)");
    scanf("%s", mot2);
    strcpy(chaine, mot1); /* on copie mot1 dans chaine */
    strcat(chaine, mot2); /* on met mot2 à la suite */
    printf("Les deux mots saisis sont : %s\n    ", chaine);
    return 0;
 }

