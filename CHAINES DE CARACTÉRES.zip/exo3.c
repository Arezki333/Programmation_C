#include <stdio.h>
#include <stdlib.h>


/*ne marche pas */
char *recopie(char *s)
 {
    int taille = 0;
    int t,u;
    char *copie;
    while (s[taille] != '\0')
     {
        s[taille]++;
     }
     copie = calloc(taille + 1, sizeof(char));
     if (copie != NULL)
      {
        t=0;
        u=0;
        while (s[t] != '\0')
         {  
            copie[u] = s[t];
            t++;
            u++;
         }
         copie[u] = '\0';
      }
      
      return copie;
 }
 
  int main(void)
 {  
    char mot[50];
    puts("Veuillez saisir un mot (au plus 49 lettres)");
    scanf("%s", mot);
    puts(recopie(mot));
    return 0;
 }

