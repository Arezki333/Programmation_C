#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int ascii(char *s)
 {
    int somme = 0;
    int t=0;
    while (s[t] != 0)
     {
        somme += s[t];
        t++;
     }
     return somme;
}

int main(void)
 {
    char chaine[100];
    puts("Veuillez entrer une ligne, puis appuyez sur entrée");
    fgets(chaine, 100, stdin); /*pour le clavier non pas pour le fichier  */
    printf("Vous avez saisi : %s", chaine);
    printf("la sommes des carractaire de la chaine du code ascii est: %d \n",ascii(chaine));
    return 0;
 }

