#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int ordre(char *s, char *t)
 {
    int tmps = 0, tmpt = 0;
    while ((s[tmps] == t[tmpt]) && (s[tmps] != '\0') && (t[tmpt] != '\0'))
     {
        tmps++;
        tmpt++;
        }
        if ((s[tmps] == '\0') && (t[tmpt] == '\0'))
        return 0;
        if ((s[tmps] != '\0') && (t[tmpt] == '\0'))
        return 1;
        if ((s[tmps] == '\0') && (t[tmpt] != '\0'))
        return -1;
        if (s[tmps] < t[tmpt])
        return -1;
        return 1;
    }


    int main(void)
    {   int ord;
        char mot1[50], mot2[51];
       puts("Veuillez saisir un mot (au plus 49 lettres)");
       scanf("%s", mot1);
       puts("Veuillez saisir un autre mot (au plus 50 lettres)");
       scanf("%s", mot2);
       ord = (ordre(mot1,mot2));
       if (ord == 0)
       printf("les deux chaînes sont égales\n");
       else if (ord == 1)
       printf("la première chaîne est supérieure à ladeuxième dans l’ordre alphabétique\n");
       else
       printf("a première chaîne est inférieure à la deuxième dans l’ordre alphabé-tique\n");
        return 0;
    }
    