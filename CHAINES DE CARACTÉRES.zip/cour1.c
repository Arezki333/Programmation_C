#include <stdio.h>



int longueur(char* chaine)
 {
    int i;/* on teste la fin de chaîne avec le ’\0’*/
    for (i=0 ; chaine[i] != '\0' ; i++)
    {} /* bloc d’instructions vide */
    return i;
 }
 
 int main(void)
  { 
    int n;
    char chaine [101];
    puts("Veuillez entrer une chaîne (au plus 100 caractères)");
    puts(" sans espaces"); /* scanf s’arrête au premier espace */
    scanf("%s", chaine); /* lecture de la chaîne. pas de & */
    n = longueur(chaine);
    printf("Longueur de la chaîne = %d\n", n);
  }
