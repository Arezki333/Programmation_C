#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Allocation d’une chaîne juste de la bonne taille */
char* SaisieChaine(void )
 {
    char chaine[1000];
    char *econome;
    puts("Veuillez entrer une ligne (au plus 999 lettres)");
    fgets(chaine, 1000, stdin);
    econome = (char *)malloc((strlen(chaine)+1)*sizeof(char ));/*on peut aussi le faire avec malloc*/
    strcpy(econome, chaine);
    return econome;
 }

 int main(void)
 {  
    puts(SaisieChaine());
    return 0;
 }
 