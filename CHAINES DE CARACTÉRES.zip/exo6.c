#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define TAILLE 1000
int espace() 
 {
    char *s;
    int tmp, esp = 0;
    s = calloc(TAILLE, sizeof(char));
    if (s == NULL)
    return -1;
    printf("Entrez une chaine :\n");
    fgets(s, TAILLE, stdin);
    tmp = 0;
    while (s[tmp] != '\0')
     {
        if (s[tmp] == ' ' )
        esp++;
        tmp++;
     }
     return esp;
}

int main()
{   int nbr;
    nbr = espace();
    printf("voici le nombre d'espace dans la chaine entrer : %d \n",nbr);
    return 0;
}
