#include <stdio.h>
int main(void)
 {
    char chaine[500], nomfich[100];
    FILE *fp;
    puts("Veuillez entrer un nom de fichier sans espace");
    scanf("%s", nomfich);
    if ((fp = fopen(nomfich, "rt")) == NULL)
    puts("Erreur : fichier inexistant ou droits insuffisants");
    else
    {
        fgets(chaine, 500, fp); /* lecture d’une ligne */
        printf("La première ligne du fichier est:\n %s\n", chaine);
    }
    
    return 0;
}