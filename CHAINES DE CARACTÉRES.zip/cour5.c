#include <stdio.h>
int main(void)
 {
    char chaine[100];
    puts("Veuillez saisir un mot son espace");
    scanf("%s", chaine);
    printf("Vous avez saisi : ");
    puts(chaine); /* pas de guillemets : variable */
    return 0;
 }

