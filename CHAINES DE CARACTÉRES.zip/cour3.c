#include <stdio.h>
int main(void)
 {
    char chaine[100];
    puts("Veuillez entrer une ligne, puis appuyez sur entrée");
    fgets(chaine, 100, stdin); /*pour le clavier non pas pour le fichier  */
    printf("Vous avez saisi : %s", chaine);
    return 0;
 }

