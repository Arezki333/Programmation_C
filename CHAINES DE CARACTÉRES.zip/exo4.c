#include <stdio.h>
#include <string.h>
#include<stdlib.h>

char *concat(char *s, char *t)
 {
    int tailles = 0, taillet = 0;
    int tmps, tmpt, tmpc;
    char *concat;
    while (s[tailles] != '\0')
     {
        tailles++;
     }
     while (t[taillet] != '\0')
      {
        taillet++;
      }
      concat = calloc(tailles + taillet + 1, sizeof(char));
      if (concat != NULL)
       {
        tmps = 0;
        tmpt = 0;
        tmpc = 0;
        while (s[tmps] != '\0')
         {
            concat[tmpc] = s[tmps];
            tmps++;
            tmpc++;
         }
         while (t[tmpt] != '\0')
          {
            concat[tmpc] = s[tmpt];
            tmpt++;
            tmpc++;
          }
          concat[tmpc] = '\0';
      }
      return concat;
}


int main(void)
{  char mot1[50], mot2[51];
    puts("Veuillez saisir un mot (au plus 49 lettres)");
    scanf("%s", mot1);
    puts("Veuillez saisir un autre mot (au plus 50 lettres)");
    scanf("%s", mot2);
    puts(concat(mot1,mot2));

    return 0;
}
