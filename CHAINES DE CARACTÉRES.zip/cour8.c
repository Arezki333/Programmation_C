#include <stdio.h>
#include <string.h>

void SaisieLigne(char chaine[502])
 {
    puts("Veuillez entrer une ligne d’au plus 500 caractères");
    fgets(chaine, 502, stdin);/* On remplace le ’\n’ (dernier caractère) par un ’\0’*/
    chaine[strlen(chaine)-1] = '\0';
    puts(chaine);

 }

 int main(void)
  { 
    char chaine[502];
    SaisieLigne(chaine);
  }
