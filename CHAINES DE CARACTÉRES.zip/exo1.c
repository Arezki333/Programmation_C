#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int occ(char *s)
 {
    int occurrence = 0;
    int t=0;
    while (s[t] != 0)
     {
        if (s[t] == 'f')
        occurrence++;
        t++;
     }
     return occurrence;
 }

int main(void)
 {
    char chaine[100];
    puts("Veuillez entrer une ligne, puis appuyez sur entrée");
    fgets(chaine, 100, stdin); /*pour le clavier non pas pour le fichier  */
    printf("Vous avez saisi : %s\n", chaine);
    printf("le nombre d'occurrence de la lettre f est %d \n",occ(chaine));
    return 0;
 }

