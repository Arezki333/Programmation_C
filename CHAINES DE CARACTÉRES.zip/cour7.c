#include <stdio.h>
#include <string.h>
int main(void)
 {
    char mot1[50], mot2[50];
    puts("Veuillez saisir un mot (au plus 49 lettres)");
    scanf("%s", mot1);
    puts("Veuillez saisir autre mot (au plus 49 lettres)");
    scanf("%s", mot2);
    if (strcmp(mot1, mot2)==0)/*l'ordre alphabe=itique*/
    puts("les deux mots sont égaux\n");
    if (strcmp(mot1, mot2) < 0)
    printf("%s vient avant %s dans l’ordre alphabétique\n",mot1, mot2);
    if (strcmp(mot1, mot2) > 0)
    printf("%s vient après %s dans l’ordre alphabétique\n",mot1, mot2);
    return 0;
 }

