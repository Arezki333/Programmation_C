#include <stdio.h>
#include <math.h>

int main(void)
 {
    float rayon, perimetre, aire;
    printf("Entrez le rayon : ");
    scanf("%f", &rayon);
    perimetre = 2.0 * M_PI * rayon;/*M_PI c'est la canstante de pi à condition d'utiliser la BU <math.h>*/
    aire = M_PI * rayon * rayon;
    printf("Périmètre = %f\nAire = %f\n", perimetre, aire);
    return 0;
  }