#include <stdio.h>
typedef int Entier; /* Définition d’un nouveau type Entier */
int main(void)
 {
    Entier d, n;
    scanf("%d", &n);
    d = 2*n;
    printf("Le double de %d est %d\n", n, d);
    return 0;
 }