#include <stdio.h>
int main(void)
 {
    int n, dizaine, centaine;
    printf("Entrez un nombre : ");
    scanf("%d", &n);
    dizaine = (n / 10) % 10;
    centaine = (n / 100) % 10;
    printf("Le chiffre des dizaines est %d\n", dizaine);
    printf("Le chiffre des centaines est %d\n", centaine);
    return 0;
 }