#include<stdio.h>
int main(void)
 {
    float n, arrondi;
    int multiplie;
    printf("Entrez un nombre réel : ");
    scanf("%f", &n);
    multiplie = (int) ((n + 0.005) * 100);
    arrondi = multiplie / 100.0;
    printf("%f arrondi à deux chiffres est %.2f\n", n, arrondi);
    return 0;
 }