#include <stdio.h>
int main(void)
 {
    int n, parite;
    printf("Entrez un nombre : "); 
    scanf("%d", &n);
    parite = n % 2;
    printf("La parité du nombre est %d\n", parite);
    return 0;
 }