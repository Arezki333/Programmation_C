#include<stdio.h>

int main(void)
 {
    int njours;/* Convention : 0 <-> lundi, ... 6 <-> Dimanche33 jours écoulés entre le 1er avril et le 4 mai */
    njours = (33 + 3) % 7 + 1;
    printf("Le 4 mai était le %d ème jour de la semaine.\n", njours);
    return 0;
 }