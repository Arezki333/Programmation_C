#include <stdio.h>
 int main(void)
  {
    int nombre, chiffre;
    puts("Tapez un nombre entier :");
    scanf("%d", &nombre);
    chiffre = nombre%10;
    printf("Le dernier chiffre est : %d", chiffre);
    return 0;
 }


 