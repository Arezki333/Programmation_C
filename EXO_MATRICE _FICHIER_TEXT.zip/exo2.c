#include <stdio.h>
#include <stdlib.h>

int **Allocation(int m, int n)
 {
    int **tab;
    int i;
    tab = (int **) calloc(m, sizeof(int *));
    for (i = 0; i < m; i++)
    tab[i] = (int *) calloc(n, sizeof(int));
    return tab;
 }

 void Liberation(int **tab, int m, int n)
  {
    int i;
    for (i = 0; i < m; i++)
    if (n > 0)
    free(tab[i]);
    if (m > 0)
    free(tab);
  }


  int **Chargement(char *nomfichier, int *nbl, int *nbc)
   {
    FILE *fp;
    int i, j;
    int **tab;
    fp = fopen(nomfichier, "rt");
    if (fp == NULL)
    {
        puts("Erreur d’ouverture du fichier");
        exit(1);
    }
    fscanf(fp, "%d %d", nbl, nbc);
    tab = Allocation(*nbl, *nbc);
    for (i = 0; i < *nbl; i++)
     {
        for (j = 0; j < *nbc; j++)
        fscanf(fp, "%d", &tab[i][j]);
     }
     fclose(fp);
     return tab;
    }

int *Sommecoefficient(int **tab, int nbl, int nbc)
 {
    int i, j;
    int *tabsomme;
    tabsomme = (int *) calloc(nbl, sizeof(int));
    for (i = 0; i < nbl; i++)
    for (j = 0; j < nbc; j++)
    tabsomme[i] += tab[i][j];
    return tabsomme;
 }

 int main(void)
  {
    int i, nbl, nbc;
    int **tab;
    int *sommecoeff;
    tab = Chargement("fichier.txt", &nbl, &nbc);
    sommecoeff = Sommecoefficient(tab, nbl, nbc);
    for (i = 0; i < nbl; i++)
    printf("somme des coeff. ligne %d = %d\n", i + 1, sommecoeff[i]);
    free(sommecoeff);
    Liberation(tab, nbl, nbc);
    return 0;
  }

  

