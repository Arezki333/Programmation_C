#include <stdio.h>
int main(void)
{
   float f1, f2;
   printf("\nTapez deux nombres réels\n");
   puts("IMPERATIVEMENT séparés par une * ");
   scanf("%f*%f", &f1, &f2);
   printf("Vous avez tapé : %f et %f. Est-ce bien cela ?\n", f1, f2);

   return 0;
}