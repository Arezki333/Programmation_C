#include <stdio.h>
int main(void)
 {
    char c;
    printf("Tapez un caractère : ");
    scanf("%c", &c);
    printf("Le code ASCII de %c est %d\n", c, c);
    return 0;
 }