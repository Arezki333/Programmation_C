#include <stdio.h>
#include <stdlib.h> 
int main(void)
{
int nombre;
float f1;
double f2;
puts("Tapez un nombre entier :");
scanf("%d", &nombre);
printf("Vous avez tapé %d, bravo !\nEssayons encore", nombre);
printf("\nTapez deux nombres réels\n");
scanf("%f %lf", &f1, &f2);
printf("Vous avez tapé : %f et %f. Est-ce bien cela ?\n", f1, f2);
return 0;
}