#include <stdio.h>
int main(void)
 {
    int n1, n2;
    int quotient;
    float frac, l;
    char c;
    printf("Entrez deux nombres entiers : ");
    scanf("%d %d", &n1, &n2);
    quotient = n1 / n2;
    printf("Partie entière du quotient : %d\n", quotient);
    frac = (n1 / (float) n2) - quotient;
    printf("Partie fractionnaire du quotient : %f\n", frac);
    printf("Entrez un réel : ");
    scanf("%f", &l);
    c=(char)((int) (l * frac) % 256);
    printf("Caractère : %c\n", c);
    return 0;
 }